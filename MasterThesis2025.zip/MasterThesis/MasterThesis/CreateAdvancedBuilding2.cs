﻿using System.Collections.Generic;
using System.Linq;
using Grasshopper.Kernel;
using Rhino.Geometry;
using Alg1.Models;
using static Alg1.Core.Grid;
using static Alg1.Core.Breps;
using static Alg1.Core.GenerateColumns;
using static Alg1.Core.GenerateBeams;
using static Alg1.Core.GenerateSlabs;
using System;

namespace Alg1
{
    public class CreateAdvancedBuilding2 : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the CreateAdvancedBuilding2 class.
        /// </summary>
        public CreateAdvancedBuilding2()
          : base("CreateAdvancedBuilding2", "Nickname",
              "Creates a building in a brep or a brep grpup. Startingpoint in mid if one brep, startingpoint in corner if more. The structure extends to fill the whole brep. In addition creates the bracings",
              "Category", "Building")
        {
            
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddBrepParameter("Breps", "B", "Building volumes", GH_ParamAccess.list);
            pManager.AddPointParameter("Starting Point", "SP", "", GH_ParamAccess.item, new Point3d(0, 0, 0));
            pManager.AddNumberParameter("X spacing", "XS", "Spacing between columns in X direction", GH_ParamAccess.item);
            pManager.AddNumberParameter("Y spacing", "YS", "Spacing between columns in Y direction", GH_ParamAccess.item);
            pManager.AddNumberParameter("Floor height", "FH", "Height of each floor", GH_ParamAccess.item);
            pManager.AddBooleanParameter("FilterCornerPoints", "", "", GH_ParamAccess.item, true);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "", "", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            List<Brep> breps = new List<Brep>();
            Point3d basePoint = Point3d.Origin;
            double xSpac = 0, ySpac = 0, fh = 0;

            DA.GetDataList(0, breps);
            DA.GetData(1, ref basePoint);
            DA.GetData(2, ref xSpac);
            DA.GetData(3, ref ySpac);
            DA.GetData(4, ref fh);

            var grupper = GroupIntersectingBreps(breps);
            var allGridPoints = new List<Point3d>();
            var allintersectionPoints = new List<Point3d>();
            var allCornerPoints = new List<Point3d>();

            Building building = new Building();


            foreach (var gruppe in grupper)
            {
                Point3d localStart = FindstartPointForGroup(gruppe); //Finner lokalt startpunkt for hver gruppe
                Point3d justert = localStart + new Vector3d(basePoint.X, basePoint.Y, 0); //Lager sammenheng mellom startingpoint og lokal startpunkt

                var grid = Generate3DGrid(gruppe, justert, xSpac, ySpac, fh);
                allGridPoints.AddRange(grid.ConvertAll(gp => gp.Point));


                var gridLines = CreateLinesThroughGridPoints(grid, 10); // ekstra lengde 10 i begge retninger
                var intersectionPoints = FindIntersectionsWithBrep(gridLines, gruppe, 0.001); // Finn kryssingspunktene
                allintersectionPoints.AddRange(intersectionPoints); // Legg til kryssingspunktene i gridet

                var cornerPts = GenerateCornerPointsPerBrep(gruppe, fh);
                allCornerPoints.AddRange(cornerPts);

            }

            double distanceThreshold = 1.2;
            bool keepAll = true;
            DA.GetData(5, ref keepAll);

            var gridPointsForBeams = new List<Point3d>(allGridPoints);
            var cornerPointsForBeams = new List<Point3d>(allCornerPoints);
            var intersectionPointsForBeams = new List<Point3d>(allintersectionPoints);

            // Fjern intersectionpunkter som overlapper med corner
            allintersectionPoints = allintersectionPoints
                .Where(ip => !allCornerPoints.Any(cp => cp.DistanceTo(ip) < 0.001))
                .ToList();

            // Fjern intersectionPoints som overlapper med hovedgrid før videre filtrering
            allintersectionPoints = allintersectionPoints
                .Where(ip => !allGridPoints.Any(gp => gp.DistanceTo(ip) < 0.001)) // eller annen lav toleranse
                .ToList();

            // Fjern hjørnepunkter som overlapper med hovedgrid
            allCornerPoints = allCornerPoints
                .Where(cp => !allGridPoints.Any(gp => gp.DistanceTo(cp) < 0.001))
                .ToList();

            // Kopier originalen før filtrering
            var originalIntersections = new List<Point3d>(allintersectionPoints);



            if (!keepAll)
            {
                // Trinn 1: Finn intersection-punkter nær hovedgrid
                var intersectCloseToGrid = allintersectionPoints
                    .Where(ip => allGridPoints.Any(gp => gp.DistanceTo(ip) <= distanceThreshold))
                    .ToList();

                // Trinn 2: Fjern disse fra intersection-punktene
                allintersectionPoints = allintersectionPoints
                    .Except(intersectCloseToGrid)
                    .ToList();

                // Trinn 3: Bruk ORIGINALE intersection-punkter til å filtrere corner-punktene
                allCornerPoints = allCornerPoints
                    .Where(cp => !originalIntersections.Any(ip => cp.DistanceTo(ip) <= distanceThreshold))
                    .ToList();

                // Trinn 4: Fjern corner-punkter som er nær hovedgrid-punktene
                allCornerPoints = allCornerPoints
                    .Where(cp => !allGridPoints.Any(gp => cp.DistanceTo(gp) <= distanceThreshold))
                    .ToList();
            }
            else
            {
                // True: Fjern grid-punkter nær intersection-punkter
                allGridPoints = allGridPoints
                    .Where(gp => !allintersectionPoints.Any(ip => gp.DistanceTo(ip) <= distanceThreshold))
                    .ToList();

                // Fjern grid-punkter som ligger ≤ 1 m fra corner-punktene
                allGridPoints = allGridPoints
                    .Where(gp => !allCornerPoints.Any(cp => gp.DistanceTo(cp) <= distanceThreshold))
                    .ToList();

                // Fjern intersection-punkter som ligger ≤ 1 m fra corner-punktene
                allintersectionPoints = allintersectionPoints
                    .Where(ip => !allCornerPoints.Any(cp => cp.DistanceTo(ip) <= distanceThreshold))
                    .ToList();


            }

            var samletPunkter = new List<Point3d>();
            samletPunkter.AddRange(allGridPoints.Concat(allintersectionPoints).Concat(allCornerPoints)); //Legger til alle punktene i en liste
            samletPunkter = Point3d.CullDuplicates(samletPunkter, 0.001).ToList();                      //Fjerner duplikater

            //Bjelker
            var gridForBeams = gridPointsForBeams
            .Where(gp =>
                !intersectionPointsForBeams.Any(ip => gp.DistanceTo(ip) <= distanceThreshold) &&
                !cornerPointsForBeams.Any(cp => gp.DistanceTo(cp) <= distanceThreshold))
            .ToList();

            var intersectionForBeams = intersectionPointsForBeams
                .Where(ip => !cornerPointsForBeams.Any(cp => cp.DistanceTo(ip) <= distanceThreshold))
                .ToList();

            var samletPunkterForBeams = new List<Point3d>();
            samletPunkterForBeams.AddRange(gridForBeams.Concat(intersectionForBeams).Concat(cornerPointsForBeams));

            double snapTol = 1e-3; // 1 mm
            Point3d Snap(Point3d p)
            {
                return new Point3d(
                  Math.Round(p.X / snapTol) * snapTol,
                  Math.Round(p.Y / snapTol) * snapTol,
                  Math.Round(p.Z / snapTol) * snapTol
                );
            }

            samletPunkterForBeams = samletPunkterForBeams
  .Select(p => Snap(p))
  .ToList();
            samletPunkterForBeams = Point3d.CullDuplicates(samletPunkterForBeams, 0.001).ToList();

            var beams = GenerateBeamsFromPoints(samletPunkterForBeams);
            beams = FilterBeamsInsideOrOnBreps(beams, breps);

            building.Beams = beams; //Alle bjelker

            List<Beam> xBeams, yBeams;
            SplitBeamsByDirection(beams, out xBeams, out yBeams); //Splitter bjelker i x og y-retning
            SortBeamsByLengthDominance(xBeams, yBeams, out var primaryBeams, out var secondaryBeams); //Sorterer primary and secondary
            SplitPrimaryIntoMiddleAndEdgeByBoundingBox(primaryBeams, grupper, out var middleBeams, out var edgeBeams); //Finner edge og interalbeams. 

            //Setter opp BeamSublists:
            building.BeamSublists = new List<List<Beam>>
            {
                middleBeams, // Index 0 = Internal beams
                edgeBeams,   // Index 1 = Edge beams
                secondaryBeams // Index 2 = Secondary beams
            };


            //Søyler
            var columns = GenerateColumnsFromPoints(samletPunkter);
            building.Columns = columns;

            //Dekke
            var alleBreps = grupper.SelectMany(g => g).ToList();
            var slabs = SplitSlabsWithBeams(GenerateSlab(samletPunkterForBeams, alleBreps), beams);
            building.Slabs = slabs;


            double tol = 1e-6;
            var allBraces = new List<Line>();

            // 1) Group column endpoints by floor level (Z)
            var colsByLevel = columns
              .SelectMany(c => new[] { c.Axis.From, c.Axis.To })
              .GroupBy(p => Math.Round(p.Z / tol) * tol)
              .ToDictionary(
                g => g.Key,
                g => g.Distinct(new Point3dEqualityComparer(tol))
                      .OrderBy(p => p.X).ThenBy(p => p.Y).ToList()
              );

            var levels = colsByLevel.Keys.OrderBy(z => z).ToArray();

            // 2) For each story pair, X‐ and Y‐brace every bay
            for (int k = 0; k < levels.Length - 1; ++k)
            {
                double zLow = levels[k], zUp = levels[k + 1];
                var lowPts = colsByLevel[zLow];
                var upPts = colsByLevel[zUp];



                // 2A) X‐direction (rows of equal Y)
                foreach (var row in lowPts.GroupBy(p => Math.Round(p.Y / tol) * tol))
                {
                    double yKey = row.Key;
                    var rowLow = row.OrderBy(p => p.X).ToList();
                    var rowUp = upPts.Where(p => Math.Abs(p.Y - yKey) < tol)
                                      .OrderBy(p => p.X).ToList();
                    int n = Math.Min(rowLow.Count, rowUp.Count);
                    for (int i = 0; i < n - 1; ++i)
                    {
                        allBraces.Add(new Line(Snap(rowLow[i]), Snap(rowUp[i + 1])));
                        allBraces.Add(new Line(Snap(rowLow[i + 1]), Snap(rowUp[i])));
                    }
                }

                // 2B) Y‐direction (columns of equal X)
                foreach (var col in lowPts.GroupBy(p => Math.Round(p.X / tol) * tol))
                {
                    double xKey = col.Key;
                    var colLow = col.OrderBy(p => p.Y).ToList();
                    var colUp = upPts.Where(p => Math.Abs(p.X - xKey) < tol)
                                      .OrderBy(p => p.Y).ToList();
                    int n = Math.Min(colLow.Count, colUp.Count);
                    for (int i = 0; i < n - 1; ++i)
                    {
                        allBraces.Add(new Line(Snap(colLow[i]), Snap(colUp[i + 1])));
                        allBraces.Add(new Line(Snap(colLow[i + 1]), Snap(colUp[i])));
                    }
                }
            }
            // suppose you have:
            List<Brep> footprints = breps;

            // keep only those braces whose midpoint lies inside *any* footprint Brep
            var keptLines = allBraces
              .Where(l => {
                  // compute midpoint
                  var mid = new Point3d(
        0.5 * (l.From.X + l.To.X),
        0.5 * (l.From.Y + l.To.Y),
        0.5 * (l.From.Z + l.To.Z)
      );
                  // test midpoint against each Brep in the list
                  return footprints.Any(fp => fp.IsPointInside(mid, tol, false));
              })
              .ToList();

            // now wrap and assign
            building.Bracings = keptLines
              .Select(l => new Bracing(l))
              .ToList();


            DA.SetData(0, building);
        }


        

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("114D238E-B631-4B20-927D-DB0ED22DF425"); }
        }
    }
}