﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Geometry;

namespace Alg1.Models
{
    public class Beam // Curve for CreateComplexBuilding (MeshGenerator2 and DeconstructBuilding2), Line for the rest of the components
    {
        public Line Axis { get; set; }  // Beam's central axis

        public Beam(Line axis)
        {
            Axis = axis;
        }
    }
}
