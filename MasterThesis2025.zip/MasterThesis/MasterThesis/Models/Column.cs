﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Geometry;

namespace Alg1.Models
{
    internal class Column // Curve for CreateComplexBuilding (MeshGenerator2 and DeconstructBuilding2), Line for the rest of the components
    {
        
        public Line Axis { get; set; }  // Column's central axis
        public double Height => Axis.Length;

        
        public Point3d BasePoint => Axis.From; //Axis.PointAtStart;
        public Point3d TopPoint => Axis.To; //Axis.PointAtEnd;

        // Constructor
        public Column(Line axis)
        {
            Axis = axis;
        }

        // Debugging Helper
        public override string ToString()
        {
            return $"Column: Base {BasePoint}, Top {TopPoint}, Height: {Height:F2}";
        }
    }
}
