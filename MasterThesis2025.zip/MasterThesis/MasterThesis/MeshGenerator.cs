﻿using System;
using System.Collections.Generic;
using Grasshopper.Kernel;
using Rhino.Geometry;
using System.Linq;
using Grasshopper.Kernel.Types;
using Grasshopper.Kernel.Data;
using Karamba.Utilities;
using Karamba.Results;
using Karamba.Materials;
using Karamba.Geometry;
using Karamba.CrossSections;
using Karamba.Supports;
using Karamba.Loads;
using Karamba.Models;
using Karamba.GHopper.Models;
using Karamba.GHopper.Utilities.Mesher;
using static Rhino.DocObjects.PhysicallyBasedMaterial;
using Karamba.GHopper.Geometry;
using static Rhino.Render.CustomRenderMeshes.RenderMeshProvider;
using Karamba.Joints;
using Karamba.Algorithms;
using System.Diagnostics;
using Karamba.Elements;
using Karamba.GHopper.Results;
using Karamba.Loads.Combination;
using Karamba.Factories;
using Karamba.Utilities.Mesher;
using System.Threading;
using static Karamba.Utilities.PathUtil;
using System.Xml.Linq;
using Grasshopper.Rhinoceros;
using Karamba.Loads.Beam;
using Grasshopper;
using System.Drawing.Drawing2D;

namespace Alg1
{
    public class MeshGenerator : GH_Component
    {
        public MeshGenerator()
          : base("MeshGenerator", "Nickname",
              "Description",
              "Category", "Karamba")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddLineParameter("Columns", "cols", "Columns of the building", GH_ParamAccess.list);
            pManager.AddBrepParameter("Slabs", "sbs", "Slabs breps of the building", GH_ParamAccess.list);
            pManager.AddLineParameter("InternalBeams", "ibms", "Internal beams of the building", GH_ParamAccess.list);
            pManager.AddLineParameter("ExternalBeams", "ebms", "External beams of the building", GH_ParamAccess.list);
            pManager.AddLineParameter("SecondaryBeams", "sbms", "Secondary beams of the building", GH_ParamAccess.list);
        }
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddMeshParameter("Mesh", "s", "Support points", GH_ParamAccess.list);
            pManager.AddCurveParameter("internalBeams", "intbms", "ifre", GH_ParamAccess.tree);
            pManager.AddCurveParameter("ExternalBeams", "intbms", "ifre", GH_ParamAccess.list);
            pManager.AddCurveParameter("SecondaryBeams", "intbms", "ifre", GH_ParamAccess.list);

            pManager.AddPointParameter("InternalPts", "IPts", "Tree of internal inclusion points", GH_ParamAccess.tree);
            pManager.AddCurveParameter("Columns", "intbms", "ifre", GH_ParamAccess.list);
            
           
        }
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            List<Line> internalBeams = new List<Line>();
            if (!DA.GetDataList<Line>(2, internalBeams))
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Failed to retrieve internal beams.");
                return;
            }
            List<Line> externalBeams = new List<Line>();
            if (!DA.GetDataList<Line>(3, externalBeams))
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Failed to retrieve external beams.");
                return;
            }
            List<Line> secondaryBeams = new List<Line>();
            DA.GetDataList<Line>(4, secondaryBeams);
            
            List<Line> cols = new List<Line>();
            if (!DA.GetDataList<Line>(0, cols))
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Failed to retrieve columns.");
                return;
            }
            List<Brep> slabs = new List<Brep>();
            if (!DA.GetDataList<Brep>(1, slabs))
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Failed to retrieve slabs.");
                return;
            }


            int segmentCount = 5;
            bool includeEnds = true;

            List<List<Point3d>> InclusionPtsInt = new List<List<Point3d>>();
            List<List<Point3d>> InclusionPtsExt = new List<List<Point3d>>();
            List<List<Point3d>> InclusionPtsSec = new List<List<Point3d>>();
            List<List<Point3d>> InclusionPtsCol = new List<List<Point3d>>();
            List<List<Line>> segmentsInt = new List<List<Line>>();
            List<List<Line>> segmentsExt = new List<List<Line>>();
            List<List<Line>> segmentsSec = new List<List<Line>>();
            List<List<Line>> segmentsCol = new List<List<Line>>();





            DivideLinesByCount(internalBeams, segmentCount, includeEnds, out segmentsInt, out InclusionPtsInt);
            DivideLinesByCount(externalBeams, segmentCount, includeEnds, out segmentsExt, out InclusionPtsExt);
            DivideLinesByCount(secondaryBeams, segmentCount, includeEnds, out segmentsSec, out InclusionPtsSec);
            DivideLinesByCount(cols, segmentCount, includeEnds, out segmentsCol, out InclusionPtsCol);


            //Casting the 3Dpoints into the GH_structure so the Grasshopper can read them. 

            var internalTree = new GH_Structure<GH_Point>();
            for (int i = 0; i < InclusionPtsInt.Count; i++)
            {
                var branch = new GH_Path(i);
                foreach (var pt in InclusionPtsInt[i])
                    internalTree.Append(new GH_Point(pt), branch);
            }

            var externalTree = new GH_Structure<GH_Point>();
            for (int i = 0; i < InclusionPtsExt.Count; i++)
            {
                var branch = new GH_Path(i);
                foreach (var pt in InclusionPtsExt[i])
                    externalTree.Append(new GH_Point(pt), branch);
            }

            var secTree = new GH_Structure<GH_Point>();
            for (int i = 0; i < InclusionPtsSec.Count; i++)
            {
                var branch = new GH_Path(i);
                foreach (var pt in InclusionPtsSec[i])
                    secTree.Append(new GH_Point(pt), branch);
            }


            var columnPolyTree = new GH_Structure<GH_Curve>();
            for (int i = 0; i < InclusionPtsCol.Count; i++)
            {
                var pts = InclusionPtsCol[i];
                if (pts.Count < 2)
                    continue;              // can’t make a polyline with fewer than 2 points

                // build and append
                var poly = new PolylineCurve(pts);
                columnPolyTree.Append(new GH_Curve(poly), new GH_Path(i));
            }


            //Tree-list of poly lines 

            var internalPolyTree = new GH_Structure<GH_Curve>();
            for (int i = 0; i < InclusionPtsInt.Count; i++)
            {
                var pts = InclusionPtsInt[i];
                if (pts.Count < 2)
                    continue;              // can’t make a polyline with fewer than 2 points

                // build and append
                var poly = new PolylineCurve(pts);
                internalPolyTree.Append(new GH_Curve(poly), new GH_Path(i));
            }


            var externalPolyTree = new GH_Structure<GH_Curve>();
            for (int i = 0; i < InclusionPtsExt.Count; i++)
            {
                var pts = InclusionPtsExt[i];
                if (pts.Count < 2) continue;
                var poly = new PolylineCurve(pts);
                externalPolyTree.Append(new GH_Curve(poly), new GH_Path(i));
            }

            var secPolyTree = new GH_Structure<GH_Curve>();
            for (int i = 0; i < InclusionPtsSec.Count; i++)
            {
                var pts = InclusionPtsSec[i];
                if (pts.Count < 2) continue;
                var poly = new PolylineCurve(pts);
                secPolyTree.Append(new GH_Curve(poly), new GH_Path(i));
            }


            var columnPolyTree2 = new GH_Structure<GH_Curve>();
            for (int i = 0; i < InclusionPtsCol.Count; i++)
            {
                var pts = InclusionPtsCol[i];
                if (pts.Count < 2)
                    continue;              // can’t make a polyline with fewer than 2 points

                // build and append
                var poly = new PolylineCurve(pts);
                columnPolyTree2.Append(new GH_Curve(poly), new GH_Path(i));
            }



            var intInputPolyTree = new List<List<PolylineCurve>>();

            foreach (var branch in internalPolyTree.Branches)
            {
                // convert each GH_Curve into a PolylineCurve
                var list = branch
                  .Select(ghc => ghc.Value as PolylineCurve)
                  .Where(pc => pc != null)
                  .ToList();

                intInputPolyTree.Add(list);
            }


            var ExtInputPolyTree = new List<List<PolylineCurve>>();

            foreach (var branch in externalPolyTree.Branches)
            {
                // convert each GH_Curve into a PolylineCurve
                var list = branch
                  .Select(ghc => ghc.Value as PolylineCurve)
                  .Where(pc => pc != null)
                  .ToList();

                ExtInputPolyTree.Add(list);
            }

            var SecInputPolyTree = new List<List<PolylineCurve>>();

            foreach (var branch in secPolyTree.Branches)
            {
                // convert each GH_Curve into a PolylineCurve
                var list = branch
                  .Select(ghc => ghc.Value as PolylineCurve)
                  .Where(pc => pc != null)
                  .ToList();

                SecInputPolyTree.Add(list);
            }



            var colInputPolyTree = new List<List<PolylineCurve>>();

            foreach (var branch in columnPolyTree2.Branches)
            {
                // convert each GH_Curve into a PolylineCurve
                var list = branch
                  .Select(ghc => ghc.Value as PolylineCurve)
                  .Where(pc => pc != null)
                  .ToList();

                colInputPolyTree.Add(list);
            }




            List<List<Line>> colSegmentTree;
            List<List<Point3d>> colPointTree;

            DividePolylinesByCount(
              colInputPolyTree,    // your nested lists of polylines
              segmentCount: 5,
              includeEnds: true,
              out colSegmentTree,
              out colPointTree
            );

            var lengthTreeCol = colSegmentTree
             .Select(branch => branch.Select(seg => seg.Length).ToList())
             .ToList();

            List<List<Line>> colNewSegmentTree;
            List<List<Point3d>> colNewPointTree;

            DivideLinesByCountTree(
                          colSegmentTree,    // your List<List<Line>> 
                          lengthTreeCol,     // List<List<double>> of counts
                          includeEnds: true, // whether to include start/end
                          out colNewSegmentTree,
                          out colNewPointTree
                        );





            var colPolyTree = new GH_Structure<GH_Curve>();

            for (int i = 0; i < colNewSegmentTree.Count; i++)
            {
                var branch = colNewSegmentTree[i];
                for (int j = 0; j < branch.Count; j++)
                {
                    Line ln = branch[j];

                    // build a two‐point polyline
                    var poly = new PolylineCurve(new[] { ln.From, ln.To });

                    // append under path {i;j}
                    colPolyTree.Append(
                      new GH_Curve(poly),
                      new GH_Path(i, j)
                    );
                }
            }



            List<List<Line>> intSegmentTree;
            List<List<Point3d>> pointTree;



            DividePolylinesByCount(
              intInputPolyTree,    // your nested lists of polylines
              segmentCount: 5,
              includeEnds: true,
              out intSegmentTree,
              out pointTree
            );
            var lengthTreeInt = intSegmentTree
             .Select(branch => branch.Select(seg => seg.Length).ToList())
             .ToList();






            List<List<Line>> intNewSegmentTree;
            List<List<Point3d>> intNewPointTree;

            DivideLinesByCountTree(
              intSegmentTree,    // your List<List<Line>> 
              lengthTreeInt,     // List<List<double>> of counts
              includeEnds: true, // whether to include start/end
              out intNewSegmentTree,
              out intNewPointTree
            );

            var intPolyTree = new GH_Structure<GH_Curve>();

            for (int i = 0; i < intNewSegmentTree.Count; i++)
            {
                var branch = intNewSegmentTree[i];
                for (int j = 0; j < branch.Count; j++)
                {
                    Line ln = branch[j];

                    // build a two‐point polyline
                    var poly = new PolylineCurve(new[] { ln.From, ln.To });

                    // append under path {i;j}
                    intPolyTree.Append(
                      new GH_Curve(poly),
                      new GH_Path(i, j)
                    );
                }
            }

            var ghNewPtTreeInt = new GH_Structure<GH_Point>();

            // 2) Loop through each branch
            for (int i = 0; i < intNewPointTree.Count; i++)
            {
                var path = new GH_Path(i);

                // 3) Append each point in that branch
                foreach (var pt in intNewPointTree[i])
                    ghNewPtTreeInt.Append(new GH_Point(pt), path);
            }


















            List<List<Line>> extSegmentTree;
            List<List<Point3d>> extPointTree;

            DividePolylinesByCount(
              ExtInputPolyTree,    // your nested lists of polylines
              segmentCount: 5,
              includeEnds: true,
              out extSegmentTree,
              out extPointTree
            );

            var lengthTreeExt = extSegmentTree
            .Select(branch => branch.Select(seg => seg.Length).ToList())
            .ToList();




            List<List<Line>> ExtNewSegmentTree;
            List<List<Point3d>> ExtNewPointTree;

            DivideLinesByCountTree(
              extSegmentTree,    // your List<List<Line>> 
              lengthTreeExt,     // List<List<double>> of counts
              includeEnds: true, // whether to include start/end
              out ExtNewSegmentTree,
              out ExtNewPointTree
            );


            var extPolyTree = new GH_Structure<GH_Curve>();

            for (int i = 0; i < ExtNewSegmentTree.Count; i++)
            {
                var branch = ExtNewSegmentTree[i];
                for (int j = 0; j < branch.Count; j++)
                {
                    Line ln = branch[j];

                    // build a two‐point polyline
                    var poly = new PolylineCurve(new[] { ln.From, ln.To });

                    // append under path {i;j}
                    extPolyTree.Append(
                      new GH_Curve(poly),
                      new GH_Path(i, j)
                    );
                }
            }

            var ghNewPtTreeExt = new GH_Structure<GH_Point>();

            // 2) Loop through each branch
            for (int i = 0; i < ExtNewPointTree.Count; i++)
            {
                var path = new GH_Path(i);

                // 3) Append each point in that branch
                foreach (var pt in ExtNewPointTree[i])
                    ghNewPtTreeExt.Append(new GH_Point(pt), path);
            }




            List<List<Line>> secSegmentTree;
            List<List<Point3d>> secPointTree;

            DividePolylinesByCount(
              SecInputPolyTree,    // your nested lists of polylines
              segmentCount: 5,
              includeEnds: true,
              out secSegmentTree,
              out secPointTree
            );


            var lengthTreeSec = secSegmentTree
            .Select(branch => branch.Select(seg => seg.Length).ToList())
            .ToList();

            List<List<Line>> SecNewSegmentTree;
            List<List<Point3d>> SecNewPointTree;

            DivideLinesByCountTree(
              secSegmentTree,    // your List<List<Line>> 
              lengthTreeSec,     // List<List<double>> of counts
              includeEnds: true, // whether to include start/end
              out SecNewSegmentTree,
              out SecNewPointTree
            );



            var secPolyTree1 = new GH_Structure<GH_Curve>();

            for (int i = 0; i < SecNewSegmentTree.Count; i++)
            {
                var branch = SecNewSegmentTree[i];
                for (int j = 0; j < branch.Count; j++)
                {
                    Line ln = branch[j];

                    // build a two‐point polyline
                    var poly = new PolylineCurve(new[] { ln.From, ln.To });

                    // append under path {i;j}
                    secPolyTree1.Append(
                      new GH_Curve(poly),
                      new GH_Path(i, j)
                    );
                }
            }


            var ghNewPtTreeSec = new GH_Structure<GH_Point>();

            // 2) Loop through each branch
            for (int i = 0; i < SecNewPointTree.Count; i++)
            {
                var path = new GH_Path(i);

                // 3) Append each point in that branch
                foreach (var pt in SecNewPointTree[i])
                    ghNewPtTreeSec.Append(new GH_Point(pt), path);
            }




            //Adding all of the point form the division to the one big list for the meshing :D 

            var allPtsNew = new List<Point3d>();


            allPtsNew.AddRange(intNewPointTree.SelectMany(branch => branch));
            allPtsNew.AddRange(ExtNewPointTree.SelectMany(branch => branch));
            allPtsNew.AddRange(SecNewPointTree.SelectMany(branch => branch));


            string warning;
            string info;
            List<Mesh> Meshes3D;

            Karamba.GHopper.Utilities.Mesher.MeshBrepsHeimrath.solve(slabs, allPtsNew, 1.0 , 0, 0.67, 1.0, 0.01, 0.0, 5, out warning, out info, out Meshes3D);


            List<Mesh3> meshedBreps3 = Meshes3D.Select(m => m.Convert()).ToList();



            // set the only output (index 0) to our tree:
            DA.SetDataList(0, Meshes3D);
            DA.SetDataTree(1, intPolyTree);
            DA.SetDataTree(2, extPolyTree);
            if (secPolyTree1.IsEmpty)
                AddRuntimeMessage(GH_RuntimeMessageLevel.Remark, "Secondary beams were empty – skipping mesh generation for these.");
            DA.SetDataTree(3, secPolyTree1);
            DA.SetDataTree(4, ghNewPtTreeInt);
            DA.SetDataTree(5, colPolyTree);
        }
        public static void DivideLinesByCount(
     List<Line> inputLines,
     int segmentCount,
     bool includeEnds,
     out List<List<Line>> dividedSegmentsTree,
     out List<List<Point3d>> divisionPointsTree
 )
        {
            dividedSegmentsTree = new List<List<Line>>();
            divisionPointsTree = new List<List<Point3d>>();

            foreach (Line line in inputLines)
            {
                // fallback for short lines
                if (line.Length < 0.01)
                {
                    // skip zero-length lines
                    dividedSegmentsTree.Add(new List<Line>());
                    divisionPointsTree.Add(new List<Point3d>());
                    continue;
                }

                var curve = new LineCurve(line);
                Point3d[] points;
                curve.DivideByCount(segmentCount, includeEnds, out points);

                var segBranch = new List<Line>();
                var ptBranch = new List<Point3d>();

                if (points == null || points.Length < 2)
                {
                    // Too short for division — use start and end directly
                    segBranch.Add(line);
                    ptBranch.Add(line.From);
                    ptBranch.Add(line.To);
                }
                else
                {
                    // Normal subdivision
                    for (int i = 0; i < points.Length - 1; i++)
                    {
                        var segment = new Line(points[i], points[i + 1]);
                        segBranch.Add(segment);
                    }
                    ptBranch.AddRange(points);
                }

                dividedSegmentsTree.Add(segBranch);
                divisionPointsTree.Add(ptBranch);
            }
        }

        public static void DividePolylinesByCount(
    List<List<PolylineCurve>> inputPolyTree,
    int segmentCount,
    bool includeEnds,
    out List<List<Line>> dividedSegmentsTree,
    out List<List<Point3d>> divisionPointsTree
)
        {
            dividedSegmentsTree = new List<List<Line>>();
            divisionPointsTree = new List<List<Point3d>>();

            // iterate over each branch
            foreach (var branchPolys in inputPolyTree)
            {
                // will accumulate this branch’s segments & points
                var segBranch = new List<Line>();
                var ptBranch = new List<Point3d>();

                // for each polyline in the branch
                foreach (var poly in branchPolys)
                {
                    // divide the curve
                    Point3d[] pts;
                    poly.DivideByCount(segmentCount, includeEnds, out pts);

                    if (pts != null && pts.Length >= 2)
                    {
                        // collect new segments
                        for (int i = 0; i < pts.Length - 1; i++)
                            segBranch.Add(new Line(pts[i], pts[i + 1]));

                        // collect division points
                        ptBranch.AddRange(pts);
                    }
                }

                // even empty branches must be added to keep tree alignment
                dividedSegmentsTree.Add(segBranch);
                divisionPointsTree.Add(ptBranch);
            }
        }
        public static void DivideLinesByCountTree(
    List<List<Line>> inputLineTree,
    int segmentCount,
    bool includeEnds,
    out List<List<Line>> dividedSegmentsTree,
    out List<List<Point3d>> divisionPointsTree
)
        {
            dividedSegmentsTree = new List<List<Line>>();
            divisionPointsTree = new List<List<Point3d>>();

            // for each branch
            foreach (var branchLines in inputLineTree)
            {
                var segBranch = new List<Line>();
                var ptBranch = new List<Point3d>();

                // subdivide each line in that branch
                foreach (var line in branchLines)
                {
                    var lc = new LineCurve(line);
                    Point3d[] pts;
                    lc.DivideByCount(segmentCount, includeEnds, out pts);

                    if (pts != null && pts.Length >= 2)
                    {
                        // build the small segments
                        for (int i = 0; i < pts.Length - 1; i++)
                            segBranch.Add(new Line(pts[i], pts[i + 1]));

                        // collect the division points
                        ptBranch.AddRange(pts);
                    }
                }

                // keep branch alignment even if empty
                dividedSegmentsTree.Add(segBranch);
                divisionPointsTree.Add(ptBranch);
            }
        }


        public static void DivideLinesByCountTree(
    List<List<Line>> inputLineTree,
    List<List<double>> countsTree,
    bool includeEnds,
    out List<List<Line>> dividedSegmentsTree,
    out List<List<Point3d>> divisionPointsTree
)
        {
            if (inputLineTree.Count != countsTree.Count)
                throw new ArgumentException("inputLineTree and countsTree must have the same number of branches.");

            dividedSegmentsTree = new List<List<Line>>(inputLineTree.Count);
            divisionPointsTree = new List<List<Point3d>>(inputLineTree.Count);

            for (int i = 0; i < inputLineTree.Count; i++)
            {
                var segBranch = new List<Line>();
                var ptBranch = new List<Point3d>();

                var lines = inputLineTree[i];
                var counts = countsTree[i];

                if (lines.Count != counts.Count)
                    throw new ArgumentException($"Branch {i}: line-count and count-list must be the same length.");

                for (int j = 0; j < lines.Count; j++)
                {
                    Line line = lines[j];

                    if (line.Length < 0.01)
                    {
                        // Skip zero-length or nearly-zero lines
                        continue;
                    }

                    int n = (int)Math.Round(counts[j]);
                    if (n < 1)
                    {
                        // Fallback to using original line as-is
                        segBranch.Add(line);
                        ptBranch.Add(line.From);
                        ptBranch.Add(line.To);
                        continue;
                    }

                    var lc = new LineCurve(line);
                    Point3d[] pts;
                    lc.DivideByCount(n, includeEnds, out pts);

                    if (pts == null || pts.Length < 2)
                    {
                        // Use original line if division fails
                        segBranch.Add(line);
                        ptBranch.Add(line.From);
                        ptBranch.Add(line.To);
                    }
                    else
                    {
                        for (int k = 0; k < pts.Length - 1; k++)
                            segBranch.Add(new Line(pts[k], pts[k + 1]));

                        ptBranch.AddRange(pts);
                    }
                }

                dividedSegmentsTree.Add(segBranch);
                divisionPointsTree.Add(ptBranch);
            }
        }

        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("426CBCBD-FE4F-4C50-A2E4-A229912BA023"); }
        }
    }
}