﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;
using static Alg1.Core.GenerateColumns;
using static Alg1.Core.GenerateBeams;
using static Alg1.Core.GenerateSlabs;
using Alg1.Models;
using System.Linq;

namespace Alg1
{
    public class CreateBuilding : GH_Component
    {
        public CreateBuilding()
          : base("CreateBuilding", "Nickname",
              "Startingpoint in corner",
              "Category", "Building")
        {
        }
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddBrepParameter("Brep", "", "", GH_ParamAccess.item);
            pManager.AddNumberParameter("x-spacing", "", "", GH_ParamAccess.item);
            pManager.AddNumberParameter("y-spacing", "", "", GH_ParamAccess.item);
            pManager.AddNumberParameter("FloorHeight", "", "", GH_ParamAccess.item);
        }
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "", "", GH_ParamAccess.list);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            Brep brep = null;
            double xSpacing = 0, ySpacing = 0, FloorHeight = 0;

            if (!DA.GetData(0, ref brep)) return;
            if (!DA.GetData(1, ref xSpacing)) return;
            if (!DA.GetData(2, ref ySpacing)) return;
            if (!DA.GetData(3, ref FloorHeight)) return;

            Building building = new Building();

            BoundingBox bbox = brep.GetBoundingBox(true);
            Point3d startpoint = new Point3d(bbox.Min.X, bbox.Min.Y, bbox.Min.Z);

            double minX = bbox.Min.X, maxX = bbox.Max.X;
            double minY = bbox.Min.Y, maxY = bbox.Max.Y;
            double minZ = bbox.Min.Z, maxZ = bbox.Max.Z;

            List<Point3d> gridPoints = new List<Point3d>();
            for (double i = minX; i <= maxX; i += xSpacing)
            {
                for (double j = minY; j <= maxY; j += ySpacing)
                {
                    for (double k = minZ; k <= maxZ; k += FloorHeight)
                    {
                        Point3d gridPoint = new Point3d(i, j, k);
                        gridPoints.Add(gridPoint);
                    }
                }       
            }
            var columns = GenerateColumnsFromPoints(gridPoints);

            var beams = FilterBeamsInsideOrOnBrep(GenerateBeamsFromPointsSingleBrep(gridPoints), brep);
            building.Beams = beams; 

            List<Beam> xBeams, yBeams;
            SplitBeamsByDirection(beams, out xBeams, out yBeams); //Splitter bjelker i x og y-retning
            SortBeamsByLengthDominance(xBeams, yBeams, out var primaryBeams, out var secondaryBeams); //Sorterer primary and secondary
            SplitPrimaryIntoMiddleAndEdgeByBoundingBoxSingleBrep(primaryBeams, brep, out var middleBeams, out var edgeBeams); //Finner edge og interalbeams. 

            //Setter opp BeamSublists:
            building.BeamSublists = new List<List<Beam>>
            {
                middleBeams, // Index 0 = Internal beams
                edgeBeams,   // Index 1 = Edge beams
                secondaryBeams // Index 2 = Secondary beams
            };

            var slabs = GenerateSlabsBetweenPoints(gridPoints, xSpacing, ySpacing);

            building.Columns = columns;
            building.Slabs = slabs;

            DA.SetData(0, building);

        }
        


        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("3E5E324D-5418-4F39-9AFB-FE8969C4F977"); }
        }
    }
}