﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Geometry;

namespace Alg1.Core
{
    internal class Grid
    {
        public static Point3d FindstartPointForGroup(List<Brep> group) //Finner startpunkt for hver brep-gruppe
        {
            List<(BrepFace face, BoundingBox bbox)> horisontaleFlater = new List<(BrepFace, BoundingBox)>(); //liste til horisontale flater

            // Finn alle horisontale flater i gruppen
            foreach (var brep in group)
            {
                foreach (var face in brep.Faces)
                {
                    if (!face.TryGetPlane(out Plane plane))
                        continue;

                    if (Math.Abs(plane.Normal.Z) < 0.99)
                        continue;

                    var bbox = face.GetBoundingBox(true);
                    horisontaleFlater.Add((face, bbox));
                }
            }

            if (horisontaleFlater.Count == 0)
                return Point3d.Origin;

            // Finn laveste Z-verdi
            double minZ = horisontaleFlater.Min(f => f.bbox.Min.Z);

            // Finn alle flater som ligger på denne Z-høyden (med liten toleranse)
            double tol = 0.001;
            var lavesteFlater = horisontaleFlater
                .Where(f => Math.Abs(f.bbox.Min.Z - minZ) < tol)
                .ToList();

            if (group.Count == 1 || lavesteFlater.Count == 1)
            {
                // Bare én brep i gruppa, eller bare én lavestliggende flate:
                var centroid = AreaMassProperties.Compute(lavesteFlater[0].face).Centroid;
                return centroid;
            }
            else
            {
                // Flere flater på samme laveste nivå – bruk hjørnet med minst X/Y
                Point3d hjørne = lavesteFlater
                    .Select(f => f.bbox.Min)
                    .OrderBy(p => p.X)
                    .ThenBy(p => p.Y)
                    .First();

                return hjørne;
            }

        }
        public class GridPoint
        {
            public int I, J, K;
            public Point3d Point;

            public GridPoint(int i, int j, int k, Point3d pt)
            {
                I = i;
                J = j;
                K = k;
                Point = pt;
            }
        }

        public static List<GridPoint> Generate3DGrid(
            List<Brep> gruppe,
            Point3d start,
            double xSpacing,
            double ySpacing,
            double floorHeight)
        {
            var points = new List<GridPoint>();
            BoundingBox bbox = BoundingBox.Empty;

            foreach (var brep in gruppe)
                bbox = BoundingBox.Union(bbox, brep.GetBoundingBox(true));

            int xStepsNeg = (int)Math.Ceiling((start.X - bbox.Min.X) / xSpacing);
            int xStepsPos = (int)Math.Ceiling((bbox.Max.X - start.X) / xSpacing);
            int yStepsNeg = (int)Math.Ceiling((start.Y - bbox.Min.Y) / ySpacing);
            int yStepsPos = (int)Math.Ceiling((bbox.Max.Y - start.Y) / ySpacing);
            int zSteps = (int)Math.Ceiling((bbox.Max.Z - start.Z) / floorHeight);

            for (int i = -xStepsNeg; i <= xStepsPos; i++)
            {
                for (int j = -yStepsNeg; j <= yStepsPos; j++)
                {
                    for (int k = 0; k <= zSteps; k++)
                    {
                        double x = start.X + i * xSpacing;
                        double y = start.Y + j * ySpacing;
                        double z = start.Z + k * floorHeight;

                        var pt = new Point3d(x, y, z);

                        if (IsPointInsideOrOnSurface(pt, gruppe, 0.1))
                            points.Add(new GridPoint(i, j, k, pt));
                    }
                }
            }

            return points;
        }
        public static List<Line> CreateLinesThroughGridPoints(List<GridPoint> points, double extraLength = 10)
        {
            var lines = new List<Line>();

            // Grupper punktene etter Z (nivåer)
            var levels = points.GroupBy(p => p.K);

            foreach (var level in levels)
            {
                var pointsOnLevel = level.ToList();

                // Lag linjer i X-retning (samme Y-verdi)
                var yGroups = pointsOnLevel.GroupBy(p => p.J);
                foreach (var group in yGroups)
                {
                    var sortedX = group.OrderBy(p => p.I).Select(p => p.Point).ToList();
                    var line = new Line(
                        sortedX.First() - new Vector3d(extraLength, 0, 0),
                        sortedX.Last() + new Vector3d(extraLength, 0, 0)
                    );
                    lines.Add(line);
                }

                // Lag linjer i Y-retning (samme X-verdi)
                var xGroups = pointsOnLevel.GroupBy(p => p.I);
                foreach (var group in xGroups)
                {
                    var sortedY = group.OrderBy(p => p.J).Select(p => p.Point).ToList();
                    var line = new Line(
                        sortedY.First() - new Vector3d(0, extraLength, 0),
                        sortedY.Last() + new Vector3d(0, extraLength, 0)
                    );
                    lines.Add(line);
                }
            }

            return lines;
        }
        public static List<Point3d> FindIntersectionsWithBrep(List<Line> lines, List<Brep> brepGruppe, double tolerance = 0.01)
        {
            var intersections = new List<Point3d>();

            foreach (var line in lines)
            {
                foreach (var brep in brepGruppe)
                {
                    Curve[] overlapCurves;
                    Point3d[] intersectionPoints;

                    bool success = Rhino.Geometry.Intersect.Intersection.CurveBrep(
                        line.ToNurbsCurve(),
                        brep,
                        tolerance,
                        out overlapCurves,
                        out intersectionPoints
                    );

                    if (success)
                    {
                        // Legg til vanlige intersection points
                        foreach (var pt in intersectionPoints)
                        {
                            intersections.Add(pt);
                        }

                        // Behandle overlapCurves
                        if (overlapCurves != null)
                        {
                            foreach (var overlapCurve in overlapCurves)
                            {
                                // Legg til start- og sluttpunkt av overlappende kurver
                                intersections.Add(overlapCurve.PointAtStart);
                                intersections.Add(overlapCurve.PointAtEnd);


                            }
                        }
                    }
                }
            }

            // Optional: Fjern duplikate punkter som oppstår
            intersections = Point3d.CullDuplicates(intersections, tolerance).ToList();

            return intersections;
        }
        public static List<Point3d> GenerateCornerPointsPerBrep(List<Brep> gruppe, double floorHeight)
        {
            var cornerPoints = new List<Point3d>();

            foreach (var brep in gruppe)
            {
                var bbox = brep.GetBoundingBox(true);

                // Hjørner på grunnplanet
                var baseCorners = new List<Point3d>
        {
            new Point3d(bbox.Min.X, bbox.Min.Y, bbox.Min.Z),
            new Point3d(bbox.Max.X, bbox.Min.Y, bbox.Min.Z),
            new Point3d(bbox.Min.X, bbox.Max.Y, bbox.Min.Z),
            new Point3d(bbox.Max.X, bbox.Max.Y, bbox.Min.Z)
        };

                // Antall nivåer i høyden
                int zSteps = (int)Math.Ceiling((bbox.Max.Z - bbox.Min.Z) / floorHeight);

                // Lag punkter i høyden for hvert hjørne
                for (int k = 0; k <= zSteps; k++)
                {
                    double z = bbox.Min.Z + k * floorHeight;

                    foreach (var basePt in baseCorners)
                    {
                        var pt = new Point3d(basePt.X, basePt.Y, z);

                        if (IsPointInsideOrOnSurface(pt, new List<Brep> { brep }, 0.1))
                            cornerPoints.Add(pt);
                    }
                }
            }

            return cornerPoints;
        }
        public class Point3dEqualityComparer : IEqualityComparer<Point3d>
        {
            private readonly double _tolerance;

            public Point3dEqualityComparer(double tolerance)
            {
                _tolerance = tolerance;
            }

            public bool Equals(Point3d a, Point3d b)
            {
                return a.DistanceTo(b) <= _tolerance;
            }

            public int GetHashCode(Point3d pt)
            {
                // HashCode med avrunding for å håndtere toleranse
                int x = (int)Math.Round(pt.X / _tolerance);
                int y = (int)Math.Round(pt.Y / _tolerance);
                int z = (int)Math.Round(pt.Z / _tolerance);
                return x ^ y ^ z;
            }
        }




        public static bool IsPointInsideOrOnSurface(Point3d pt, List<Brep> brepGruppe, double tolerance = 0.1)
        {
            foreach (var brep in brepGruppe)
            {
                if (brep.IsPointInside(pt, tolerance, true))
                    return true;

                foreach (var face in brep.Faces)
                {
                    if (face.ClosestPoint(pt, out double u, out double v))
                    {
                        // Sjekk at punktet er innenfor trimmed område
                        var relation = face.IsPointOnFace(u, v);
                        if (relation != PointFaceRelation.Exterior)
                        {
                            Point3d projected = face.PointAt(u, v);
                            if (pt.DistanceTo(projected) < tolerance)
                                return true;
                        }
                    }
                }
            }

            return false;
        }
    }
}
