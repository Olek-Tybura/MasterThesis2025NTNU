﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Geometry;

namespace Alg1.Core
{
    internal class Breps
    {
        public static List<List<Brep>> GroupIntersectingBreps(List<Brep> breps) //finner grupper med breper som intersecter
        {
            var groups = new List<List<Brep>>(); //Liste som skal inneholde grupper av Brep-objekter

            foreach (var brep in breps) //looper gjennom alle breper
            {
                BoundingBox bb1 = brep.GetBoundingBox(true); //finner boundingbox til brepene
                List<List<Brep>> overlappingGroups = new List<List<Brep>>();

                foreach (var group in groups) //finner breper som intersecter, og lager gruppe
                {
                    if (group.Any(b => BoundingBox.Intersection(bb1, b.GetBoundingBox(true)).IsValid))
                    {
                        overlappingGroups.Add(group);
                    }

                }

                if (overlappingGroups.Count == 0) //lager gruppe for breper som ikke intersecter
                {
                    groups.Add(new List<Brep> { brep });
                }
                else
                {
                    List<Brep> mergedGroup = new List<Brep> { brep };
                    foreach (var g in overlappingGroups)
                    {
                        mergedGroup.AddRange(g);
                        groups.Remove(g);
                    }
                    groups.Add(mergedGroup);
                }
            }
            return groups;
        }
    }
}
