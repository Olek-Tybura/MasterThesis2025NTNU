﻿using System;
using System.Collections.Generic;
using System.Linq;
using Alg1.Models;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
namespace Alg1
{
    public class PreviewResults2 : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the PreviewResults2 class.
        /// </summary>
        public PreviewResults2()
          : base("PreviewResults2", "Nickname",
              "Calculates volumes and sorts the inputs ofr further analysis, with addition of the bracings",
              "Category", "Analysis")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddIntegerParameter("BuildingType", "BT", "1=HC+Steel, 2=CLT+Glulam, 3=CastConcrete", GH_ParamAccess.item);

            pManager.AddTextParameter("BeamIDs", "ID", "IDs of beams and columns", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamLengths", "L", "Lengths of beams/columns [m]", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamAreas", "A", "Cross-sectional area of each element [cm²]", GH_ParamAccess.list);

            pManager.AddBooleanParameter("IsActiveBracing", "Active?", "Boolean list from Karamba 'Element is Active' (used for bracing filter)", GH_ParamAccess.list);

            pManager.AddNumberParameter("SlabAreas", "SlabA", "Plan area of slabs [m²]", GH_ParamAccess.list);
            pManager.AddNumberParameter("SlabThickness", "SlabT", "Thickness of slabs [cm]", GH_ParamAccess.tree);

            pManager.AddNumberParameter("HCLength", "HClen", "Span lengths from secondary beams", GH_ParamAccess.list);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddIntegerParameter("BuildingType", "BT", "1, 2 or 3", GH_ParamAccess.item);
            pManager.AddTextParameter("BeamIDs", "ID", "All beam/column IDs", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamLengths", "L", "Length per element [m]", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamAreas", "A", "Cross-sectional area per element [cm²]", GH_ParamAccess.list);
            pManager.AddNumberParameter("VolumeColumns [m³]", "VolCols", "Volume of columns [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeBeams [m³]", "VolBms", "Volume of beams [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeSlabs [m³]", "VolSlabs", "Volume of slabs [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeBracing [m³]", "VolBrace", "Total volume of bracing elements [m³]. Returns 0 if no bracing is found.", GH_ParamAccess.item);


            pManager.AddNumberParameter("AreaSlabs", "SlabA", "Total plan area of all slabs [m²]", GH_ParamAccess.item);
            pManager.AddTextParameter("HCProfile", "HCProf", "Selected hollow-core profile", GH_ParamAccess.item);

        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {


            // Read basic input: Building type
            // Retrieve input: building type
            int bt = 0;
            if (!DA.GetData(0, ref bt)) return;

            // Retrieve lists from input
            var ids = new List<string>();
            var lengths = new List<double>();
            var areasCm2 = new List<double>();
            var isActive = new List<bool>();
            var slabAreas = new List<double>();
            var slabTree = new GH_Structure<GH_Number>();
            var hcLengths = new List<double>();

            if (!DA.GetDataList(1, ids)) return;
            if (!DA.GetDataList(2, lengths)) return;
            if (!DA.GetDataList(3, areasCm2)) return;
            if (!DA.GetDataList(4, isActive)) return;
            if (!DA.GetDataList(5, slabAreas)) return;
            if (!DA.GetDataTree(6, out slabTree)) return;
            if (bt == 1 && !DA.GetDataList(7, hcLengths)) return;

            // Check that all input lists have matching lengths
            if (ids.Count != lengths.Count || ids.Count != areasCm2.Count || ids.Count != isActive.Count)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "BeamIDs, BeamLengths, BeamAreas and IsActiveBracing must all have the same number of items.");
                return;
            }

            // Convert cm² to m²
            var areas = areasCm2.Select(a => a / 10000.0).ToList();
            List<double> slabThs = null;

            // Convert slab thickness from cm to meters if not BT1
            if (bt != 1)
            {
                slabThs = slabTree.FlattenData().Select(n => n.Value / 100.0).ToList();
                if (slabThs.Count == 1)
                    slabThs = Enumerable.Repeat(slabThs[0], slabAreas.Count).ToList();

                if (slabThs.Count != slabAreas.Count)
                {
                    AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "SlabThickness must be one value or match number of SlabAreas.");
                    return;
                }
            }

            // Initialize output variables for volume sums
            double volCols = 0, volBms = 0, volSlabs = 0, volBracing = 0;

            // Classify and sum volumes by category
            for (int i = 0; i < ids.Count; i++)
            {
                double v = areas[i] * lengths[i];
                string id = ids[i].ToLower();

                if (id.Contains("col"))
                    volCols += v;
                else if (id.Contains("bracing") && isActive[i])
                    volBracing += v * 2;
                else if (!id.Contains("bracing"))
                    volBms += v;
            }

            // Calculate hollow-core slab profile span (BT1 only)
            double spanForProf = (bt == 1) ? DetermineHCSpan(hcLengths) : 0.0;

            // Calculate slab volume
            for (int i = 0; i < slabAreas.Count; i++)
            {
                if (bt == 1)
                {
                    double A_HC = GetHCProfileArea(spanForProf);
                    volSlabs += (slabAreas[i] / 1.2) * A_HC;
                }
                else
                {
                    volSlabs += slabAreas[i] * slabThs[i];
                }
            }

            // Total slab area
            double areaSum = slabAreas.Sum();

            // Select appropriate HC profile name
            string hcProf = bt == 1
                ? (spanForProf <= 10 ? "HC200"
                  : spanForProf <= 13 ? "HC265"
                  : spanForProf <= 15 ? "HC320"
                  : spanForProf <= 17 ? "HC400"
                  : "HC500")
                : "N/A";

            // Output values
            DA.SetData(0, bt);
            DA.SetDataList(1, ids);
            DA.SetDataList(2, lengths);
            DA.SetDataList(3, areasCm2);
            DA.SetData(4, volCols);
            DA.SetData(5, volBms);
            DA.SetData(6, volSlabs);
            DA.SetData(7, volBracing);
            DA.SetData(8, areaSum);
            DA.SetData(9, hcProf);
        }

        // Compute the dominant or average span length used for HC slab classification
        private double DetermineHCSpan(List<double> hcLengths)
        {
            if (hcLengths.Count == 0) return 0.0;
            var grouped = hcLengths.GroupBy(x => x).Select(g => new { Value = g.Key, Count = g.Count() }).OrderByDescending(g => g.Count).ToList();
            return grouped[0].Count > 1 ? grouped[0].Value : hcLengths.Average();
        }

        // Determine hollow-core slab cross-sectional area [m²] based on span length
        private double GetHCProfileArea(double span)
        {
            if (span <= 10) return 0.13;
            if (span <= 13) return 0.17;
            if (span <= 15) return 0.19;
            if (span <= 17) return 0.22;
            return 0.304;
        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("293AFDE6-56C9-4874-996E-AF66E6EDDB59"); }
        }
    }
}