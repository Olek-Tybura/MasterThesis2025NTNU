﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace Alg1
{
    public class Emissions2 : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the Emissions2 class.
        /// </summary>
        public Emissions2()
          : base("Emissions2", "Nickname",
              "Calculates CO2 emission of each structural element, with addition of bracings",
              "Category", "Analysis")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            // 0. Building type
            pManager.AddIntegerParameter("BuildingType", "BT", "1 = HC + Steel, 2 = CLT + Glulam, 3 = Cast-In-Place Concrete", GH_ParamAccess.item);

            // 1–3. Volumes
            pManager.AddNumberParameter("VolumeColumns", "VolCols", "Total volume of columns [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeBeams", "VolBms", "Total volume of beams [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeSlabs", "VolSlabs", "Total volume of slabs [m³]", GH_ParamAccess.item);
            // 4. Bracing volume (optional)
            pManager.AddNumberParameter("VolumeBracing", "VolBrace", "Total volume of bracing [m³] (optional)", GH_ParamAccess.item);
            pManager[4].Optional = true;

            // 5. Concrete class selector (BT3 only)
            pManager.AddIntegerParameter("ConcreteClass", "CC", "0 = Standard, 1 = Class A, 2 = Extreme (BT3 only)", GH_ParamAccess.item);
            pManager[5].Optional = true;
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("Column CO₂-eq [kg]", "Col", "Total CO₂-equivalents for columns [kg]", GH_ParamAccess.item);
            pManager.AddNumberParameter("Beam CO₂-eq [kg]", "Beam", "Total CO₂-equivalents for beams [kg]", GH_ParamAccess.item);
            pManager.AddNumberParameter("Slab CO₂-eq [kg]", "Slab", "Total CO₂-equivalents for slabs [kg]", GH_ParamAccess.item);
            pManager.AddNumberParameter("Bracing CO₂-eq [kg]", "Bracing", "Total CO₂-equivalents for Bracing [kg] (0 if none found)", GH_ParamAccess.item);

            pManager.AddNumberParameter("Total CO₂-eq [kg]", "Tot", "Sum of all CO₂-equivalent values [kg]", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // 1) Declare inputs
            int bt = 0, cc = 0;
            double vC = 0.0, vB = 0.0, vS = 0.0, vBrace = 0.0;

            // 2) Get mandatory inputs
            if (!DA.GetData(0, ref bt)) return;
            if (!DA.GetData(1, ref vC)) return;
            if (!DA.GetData(2, ref vB)) return;
            if (!DA.GetData(3, ref vS)) return;

            // 3) Get optional bracing and concrete class
            DA.GetData(4, ref vBrace); // ← Correct: no if/return, stays 0 if not connected
            DA.GetData(5, ref cc);     // ← Optional as well

            // 4) Emission factors [kg CO₂-eq per m³]
            const double E_CLT = -614.0;        // CLT slabs
            const double E_GL = -726.0;         // Glulam beams and columns
            const double E_CSlab = 195.243;     // Cast-in-place concrete slabs (B30)
            const double E_CBeam = 200.494;     // Cast-in-place concrete beams/columns (B35)
            const double E_HC = 126.771;        // Hollow-core slabs
            const double E_ST = 8988.25;        // Steel beams and columns

            // 5) EPD factors for Class A low-carbon concrete
            const double E_CSlab_A = 150.0;
            const double E_CBeam_A = 160.0;

            // 6) EPD factors for Extreme low-carbon concrete
            const double E_CSlab_X = 100.0;
            const double E_CBeam_X = 120.0;

            // 7) Choose emission factor depending on building type
            double fCol, fBeam, fSlab, fBracing = 0;

            if (bt == 1) // HC + steel
            {
                fCol = fBeam = fBracing = E_ST;
                fSlab = E_HC;
            }
            else if (bt == 2) // CLT + Glulam
            {
                fCol = fBeam = E_GL;
                fSlab = E_CLT;
                fBracing = E_ST; // Bracing typically not used or not steel in BT2
            }
            else // BT3: cast-in-place
            {
                fCol = (cc == 0) ? E_CBeam : (cc == 1) ? E_CBeam_A : E_CBeam_X;
                fBeam = fCol;
                fSlab = (cc == 0) ? E_CSlab : (cc == 1) ? E_CSlab_A : E_CSlab_X;
                fBracing = E_ST; // You can adjust if needed
            }

            // 8) Calculate emissions per category
            double colCO2 = vC * fCol;
            double beamCO2 = vB * fBeam;
            double slabCO2 = vS * fSlab;
            double bracingCO2 = vBrace * fBracing;

            // 9) Total
            double total = colCO2 + beamCO2 + slabCO2 + bracingCO2;

            // 10) Set outputs
            DA.SetData(0, colCO2);
            DA.SetData(1, beamCO2);
            DA.SetData(2, slabCO2);
            DA.SetData(3, bracingCO2);
            DA.SetData(4, total);
        }
       

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("BE89ACF3-CE0D-47D3-A6ED-355DDAC99B7B"); }
        }
    }
}