﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Geometry;

namespace Alg1.Models
{
    public class Slab
    {
        // Properties
        public Brep Geometry { get; set; }
        public double Thickness { get; set; }
        public double Level { get; set; }  // Z-coordinate of the slab

        // Constructor
        public Slab(Brep geometry, double thickness, double level)
        {
            Geometry = geometry;
            Thickness = thickness;
            Level = level;
        }

        public Slab(Brep geometry)
        {
            Geometry = geometry;

        }
    }
}
