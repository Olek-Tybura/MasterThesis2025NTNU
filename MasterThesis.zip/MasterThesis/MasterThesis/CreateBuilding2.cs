﻿using System;
using System.Collections.Generic;
using System.Linq;
using Grasshopper.Kernel;
using Rhino.Geometry;
using Alg1.Models;
using static Alg1.Core.Grid;
using static Alg1.Core.Breps;
using static Alg1.Core.GenerateColumns;
using static Alg1.Core.GenerateBeams;
using static Alg1.Core.GenerateSlabs;

namespace Alg1
{
    public class CreateBuilding2 : GH_Component
    {

        public CreateBuilding2()
          : base("CreateBuilding2", "Nickname",
              "Description",
              "Category", "Subcategory")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddBrepParameter("Brep", "", "", GH_ParamAccess.list);
            pManager.AddPointParameter("Starting Point", "SP", "", GH_ParamAccess.item, new Point3d(0, 0, 0));
            pManager.AddNumberParameter("x-spacing", "", "", GH_ParamAccess.item);
            pManager.AddNumberParameter("y-spacing", "", "", GH_ParamAccess.item);
            pManager.AddNumberParameter("FloorHeight", "", "", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "", "", GH_ParamAccess.list);
        }

        
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            List<Brep> breps = new List<Brep>();
            Point3d basePoint = Point3d.Origin;
            double xSpac = 0, ySpac = 0, fh = 0;

            DA.GetDataList(0, breps);
            DA.GetData(1, ref basePoint);
            DA.GetData(2, ref xSpac);
            DA.GetData(3, ref ySpac);
            DA.GetData(4, ref fh);

            var grupper = GroupIntersectingBreps(breps);
            var allGridPoints = new List<Point3d>();
            

            Building building = new Building();


            foreach (var gruppe in grupper)
            {
                Point3d localStart = FindstartPointForGroup(gruppe); //Finner lokalt startpunkt for hver gruppe
                Point3d justert = localStart + new Vector3d(basePoint.X, basePoint.Y, 0); //Lager sammenheng mellom startingpoint og lokal startpunkt

                var grid = Generate3DGrid(gruppe, justert, xSpac, ySpac, fh);
                allGridPoints.AddRange(grid.ConvertAll(gp => gp.Point));

            }

            

            var gridPointsForBeams = new List<Point3d>(allGridPoints);
            

            

            

            var beams = GenerateBeamsFromPoints(allGridPoints);
            beams = FilterBeamsInsideOrOnBreps(beams, breps);

            building.Beams = beams; //Alle bjelker

            List<Beam> xBeams, yBeams;
            SplitBeamsByDirection(beams, out xBeams, out yBeams); //Splitter bjelker i x og y-retning
            SortBeamsByLengthDominance(xBeams, yBeams, out var primaryBeams, out var secondaryBeams); //Sorterer primary and secondary
            SplitPrimaryByMidpointExtremes(
    primaryBeams,
    out var middleBeams,
    out var edgeBeams,
    tolerance: 0.05);
            //Setter opp BeamSublists:
            building.BeamSublists = new List<List<Beam>>
            {
                middleBeams, // Index 0 = Internal beams
                edgeBeams,   // Index 1 = Edge beams
                secondaryBeams // Index 2 = Secondary beams
            };


            //Søyler
            var columns = GenerateColumnsFromPoints(allGridPoints);
            building.Columns = columns;

            //Dekke
            var slabs = GenerateSlabsFromPoints(allGridPoints);
            building.Slabs = slabs;

            DA.SetData(0, building);
        }

        
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("5D78371F-565C-4CE4-9AAF-8D4CB3E2BF63"); }
        }
    }
}