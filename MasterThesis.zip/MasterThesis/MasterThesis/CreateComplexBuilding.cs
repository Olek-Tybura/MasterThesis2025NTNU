﻿using System;
using System.Collections.Generic;
using System.Linq;
using Alg1.Models;
using Grasshopper.Kernel;
using Rhino.Geometry;
using Alg1.Models;
using System.Security.Cryptography;
using Rhino;

namespace Alg1
{
    public class CreateComplexBuilding : GH_Component
    {
        
        public CreateComplexBuilding()
          : base("CreateComplexBuilding", "Nickname",
              "Description",
              "Category", "Subcategory")
        {
        }

        
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddNumberParameter("Diameter", "D", "Diameter på sirkler", GH_ParamAccess.item, 10.0);
            pManager.AddIntegerParameter("Number of floors", "N", "Antall sirkler", GH_ParamAccess.item, 5);
            pManager.AddNumberParameter("Floor height", "H", "Total høyde mellom første og siste sirkel", GH_ParamAccess.item, 20.0);
            pManager.AddIntegerParameter("Number of points", "P", "Antall punkter jevnt fordelt per sirkel", GH_ParamAccess.item, 8);
            pManager.AddNumberParameter("Scale", "S", "Minimum skalering på midterste sirkel (0–1)", GH_ParamAccess.item, 0.0);
            pManager.AddBooleanParameter("Invert Structure", "Inv", "Snur skaleringsmønsteret (inn–ut–inn)", GH_ParamAccess.item, false);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "B", "Bygningsdata (søyle, bjelker, dekker)", GH_ParamAccess.item);
            
            
        }

        
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            double diameter = 0;
            int antall = 0;
            double høyde = 0;
            int punkterPerSirkel = 0;
            

            if (!DA.GetData(0, ref diameter)) return;
            if (!DA.GetData(1, ref antall)) return;
            if (!DA.GetData(2, ref høyde)) return;
            if (!DA.GetData(3, ref punkterPerSirkel)) return;

            List<Column> columns = new List<Column>();
            List<Beam> beams = new List<Beam>();
            List<Slab> slabs = new List<Slab>();
            List<List<Beam>> beamSublists = new List<List<Beam>>();
            beamSublists.Add(new List<Beam>()); 
            beamSublists.Add(new List<Beam>()); 
            beamSublists.Add(new List<Beam>());
            

            double minScale = 0.0;
            DA.GetData(4, ref minScale);
            minScale = Math.Max(0.0, Math.Min(1.0, minScale));

            bool invertScale = false;
            DA.GetData(5, ref invertScale);

            if (antall < 1 || diameter <= 0 || punkterPerSirkel < 1)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, "Antall, diameter og punktantall må være > 0");
                return;
            }

            double radius = diameter / 2.0;
            double step = høyde;  
            Point3d basePoint = new Point3d(0, 0, 0);
            Point3d topPoint = new Point3d(0, 0, (antall - 1) * step);
            var sirkler = new List<Curve>();
            var punkter = new List<Point3d>();
            List<Point3d> midtPunkter = new List<Point3d>();



            for (int i = 0; i < antall; i++)
            {
                double z = i * step;
                Plane plan = new Plane(new Point3d(0, 0, z), Vector3d.ZAxis);
                double half = (antall - 1) / 2.0;
                double distanceToCenter = Math.Abs(i - half);
                double t = distanceToCenter / half;

                if (invertScale)
                    t = 1.0 - t;

                double scale = minScale + (1.0 - minScale) * t;

                double rawRadius = radius * scale;
                if (rawRadius <= Rhino.RhinoMath.ZeroTolerance)
                    rawRadius = Rhino.RhinoMath.ZeroTolerance;

                Circle c = new Circle(plan, radius * scale);
                Curve kurve = c.ToNurbsCurve();

                if (kurve == null || !kurve.IsValid)
                {
                    AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, $"Ugyldig kurve på sirkel {i} (kan skyldes radius = 0).");
                    continue;
                }

                

                sirkler.Add(kurve);
                if (kurve.IsClosed && kurve.IsPlanar())
                {
                    Brep[] slab = Brep.CreatePlanarBreps(kurve);
                    if (slab != null && slab.Length > 0)
                        slabs.Add(new Slab(slab[0]));
                }

                
                double length = kurve.GetLength();
                double spacing = length / punkterPerSirkel;

                

                for (int j = 0; j < punkterPerSirkel; j++)
                {
                    double param;
                    kurve.LengthParameter(j * spacing, out param);
                    Point3d pt = kurve.PointAt(param);
                    punkter.Add(pt);
                }

                

            }

            
            for (int i = 0; i < antall; i++)
            {
                double z = i * step;
                midtPunkter.Add(new Point3d(0, 0, z));
            }

            for (int i = 0; i < sirkler.Count; i++) 
            {
                Curve sirkelKurve = sirkler[i];
                if (sirkelKurve == null || !sirkelKurve.IsValid)
                    continue;

                double length = sirkelKurve.GetLength();
                double spacing = length / punkterPerSirkel;

                List<double> parameters = new List<double>();
                for (int j = 0; j < punkterPerSirkel; j++)
                {
                    double param;
                    if (sirkelKurve.LengthParameter(j * spacing, out param))
                    {
                        parameters.Add(param);
                    }
                    
                }

                for (int j = 0; j < parameters.Count; j++)
                {
                    double t0 = parameters[j];
                    double t1 = parameters[(j + 1) % parameters.Count]; 

                    Curve segment = sirkelKurve.Trim(t0, t1);
                    if (segment != null)
                    {
                        Beam beam = new Beam(segment);
                        beams.Add(beam);
                        beamSublists[1].Add(beam); 
                    }
                }

                


                Point3d[] pts;
                sirkelKurve.DivideByCount(punkterPerSirkel, true, out pts);

                

                for (int j = 0; j < pts.Length; j++)
                {
                    Point3d a = pts[j];
                    Point3d b = pts[(j + 1) % pts.Length]; 
                    var linje = new Line(a, b);
                    Beam beam = new Beam(new LineCurve(linje));
                    beams.Add(beam);
                    beamSublists[2].Add(beam);
                }
            }

            

            for (int i = 0; i < antall; i++) 
            {
                Point3d midtpunkt = midtPunkter[i];

                for (int j = 0; j < punkterPerSirkel; j++)
                {
                    int index = i * punkterPerSirkel + j;
                    if (index < punkter.Count)
                    {
                        Point3d ytterpunkt = punkter[index];
                        Beam b = new Beam(new LineCurve(ytterpunkt, midtpunkt));
                        beams.Add(b);
                        beamSublists[0].Add(b);
                    }
                }
            }
            for (int i = 0; i < midtPunkter.Count - 1; i++)
            {
                Point3d pt1 = midtPunkter[i];
                Point3d pt2 = midtPunkter[i + 1];
                columns.Add(new Column(new LineCurve(pt1, pt2)));
            }

            List<Slab> splitSlabs = new List<Slab>();

            foreach (var slab in slabs)
            {
                Brep slabBrep = slab.Geometry;

                
                List<Curve> beamCurves = beams
                    .Select(b => b.Axis)
                    .Where(c => c != null && c.IsValid && slabBrep.ClosestPoint(c.PointAtStart).DistanceTo(c.PointAtStart) < 0.01)
                    .ToList();

                if (beamCurves.Count == 0) continue;

                
                Brep[] split = slabBrep.Split(beamCurves, Rhino.RhinoDoc.ActiveDoc.ModelAbsoluteTolerance);

                if (split != null && split.Length > 0)
                {
                    foreach (var b in split)
                        splitSlabs.Add(new Slab(b));
                }
                else
                {
                    
                    splitSlabs.Add(slab);
                }
            }
            slabs = splitSlabs
    .Where(s => s.Geometry.GetBoundingBox(true).Min.Z > Rhino.RhinoMath.ZeroTolerance)
    .ToList();

            var soylekurver = new List<Curve>();
            List<List<Point3d>> spiralPunktGrupper = new List<List<Point3d>>();
                List<List<Point3d>> motspiralPunktGrupper = new List<List<Point3d>>();

            for (int j = 0; j < punkterPerSirkel; j++)
            {
                List<Point3d> spiralPunkter = new List<Point3d>();

                for (int i = 0; i < antall; i++)
                {
                    int shiftedIndex = (j + i) % punkterPerSirkel;
                    int globalIndex = i * punkterPerSirkel + shiftedIndex;

                    if (globalIndex < punkter.Count)
                        spiralPunkter.Add(punkter[globalIndex]);
                }

                if (spiralPunkter.Count >= 2)
                {
                    spiralPunktGrupper.Add(spiralPunkter); 
                    Curve spiralKurve = Curve.CreateInterpolatedCurve(spiralPunkter, 1);
                    soylekurver.Add(spiralKurve);
                }
            }

            for (int j = 0; j < punkterPerSirkel; j++)
            {
                List<Point3d> motspiralPunkter = new List<Point3d>();

                for (int i = 0; i < antall; i++)
                {
                    int shiftedIndex = (j - i + punkterPerSirkel) % punkterPerSirkel;
                    int globalIndex = i * punkterPerSirkel + shiftedIndex;

                    if (globalIndex < punkter.Count)
                        motspiralPunkter.Add(punkter[globalIndex]);
                }

                if (motspiralPunkter.Count >= 2)
                {
                    motspiralPunktGrupper.Add(motspiralPunkter); 
                    Curve motspiralKurve = Curve.CreateInterpolatedCurve(motspiralPunkter, 1);
                    soylekurver.Add(motspiralKurve);
                }
            }
            foreach (var spiralPunkter in spiralPunktGrupper)
            {
                for (int i = 0; i < spiralPunkter.Count - 1; i++)
                {
                    Point3d pt1 = spiralPunkter[i];
                    Point3d pt2 = spiralPunkter[i + 1];
                    columns.Add(new Column(new LineCurve(pt1, pt2)));
                }
            }

            
            foreach (var motPunkter in motspiralPunktGrupper)
            {
                for (int i = 0; i < motPunkter.Count - 1; i++)
                {
                    Point3d pt1 = motPunkter[i];
                    Point3d pt2 = motPunkter[i + 1];
                    columns.Add(new Column(new LineCurve(pt1, pt2)));
                }
            }
            beams = beams.Where(b =>
            {
                var zStart = b.Axis.PointAtStart.Z;
                var zEnd = b.Axis.PointAtEnd.Z;
                return zStart > Rhino.RhinoMath.ZeroTolerance || zEnd > Rhino.RhinoMath.ZeroTolerance;
            }).ToList();

            for (int i = 0; i < beamSublists.Count; i++)
            {
                beamSublists[i] = beamSublists[i].Where(b =>
                {
                    var zStart = b.Axis.PointAtStart.Z;
                    var zEnd = b.Axis.PointAtEnd.Z;
                    return zStart > Rhino.RhinoMath.ZeroTolerance || zEnd > Rhino.RhinoMath.ZeroTolerance;
                }).ToList();
            }


            Building building = new Building("Generated", 1)
            {
                Columns = columns,
                Beams = beams,
                Slabs = slabs,
                BeamSublists = beamSublists
            };

            DA.SetData(0, building);
            
        }
       
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("68829C9D-2C22-464B-B9A0-081536D6AE7E"); }
        }
    }
}