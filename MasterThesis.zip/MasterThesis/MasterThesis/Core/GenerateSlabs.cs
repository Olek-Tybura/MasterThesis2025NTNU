﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Alg1.Models;
using Rhino.Geometry;

namespace Alg1.Core
{
    internal class GenerateSlabs
    {
        public static List<Slab> GenerateSlab(List<Point3d> points, List<Brep> breps, double defaultThickness = 0.2) //For flere breps
        {
            HashSet<double> levels = new HashSet<double>();
            foreach (var p in points)
                levels.Add(Math.Round(p.Z, 3));

            if (levels.Count > 0)
                levels.Remove(levels.Min());

            List<Plane> planes = levels
                .Select(z => new Plane(new Point3d(0, 0, z), Vector3d.ZAxis))
                .ToList();

            List<Slab> slabs = new List<Slab>();

            foreach (Plane pl in planes)
            {
                List<Curve> allCurvesAtLevel = new List<Curve>();

                foreach (var brep in breps)
                {
                    Curve[] intersectionCurves;
                    Point3d[] _;
                    Rhino.Geometry.Intersect.Intersection.BrepPlane(brep, pl, 0.001, out intersectionCurves, out _);

                    if (intersectionCurves != null)
                        allCurvesAtLevel.AddRange(intersectionCurves);
                }

                if (allCurvesAtLevel.Count == 0)
                    continue;

                // Først join: kurver som henger sammen
                Curve[] joined = Curve.JoinCurves(allCurvesAtLevel, 0.001);

                // Så: slå sammen overlappende regioner
                Curve[] unioned = Curve.CreateBooleanUnion(joined, 0.001);

                if (unioned == null) continue;

                foreach (var crv in unioned)
                {
                    if (crv.IsClosed && crv.IsPlanar())
                    {
                        var brepSlabs = Brep.CreatePlanarBreps(crv, 0.001);
                        if (brepSlabs != null && brepSlabs.Length > 0)
                        {
                            foreach (var brepSlab in brepSlabs)
                            {
                                slabs.Add(new Slab(brepSlab, defaultThickness, pl.OriginZ));
                            }
                        }
                    }
                }
            }

            return slabs;
        }
        
        public static List<Slab> SplitSlabsWithBeams(List<Slab> slabs, List<Beam> beams)
        {
            List<Slab> result = new List<Slab>();

            foreach (var slab in slabs)
            {
                Brep brep = slab.Geometry;

                BrepFace face = brep.Faces[0];
                Surface surface = face.UnderlyingSurface();

                Plane slabPlane;
                if (!surface.TryGetPlane(out slabPlane))
                {
                    result.Add(slab); // fallback: behold original slab
                    continue;
                }

                List<Curve> projectedCurves = new List<Curve>();

                foreach (var beam in beams)
                {
                    Line axis = beam.Axis;
                    if (Math.Abs(axis.From.Z - slabPlane.OriginZ) < 0.01 &&
                        Math.Abs(axis.To.Z - slabPlane.OriginZ) < 0.01)
                    {
                        LineCurve beamCurve = new LineCurve(axis);
                        Curve projected = Curve.ProjectToPlane(beamCurve, slabPlane);
                        projectedCurves.Add(projected);
                    }
                }

                if (projectedCurves.Count == 0)
                {
                    result.Add(slab);
                }
                else
                {
                    Brep[] split = brep.Split(projectedCurves, 0.001);
                    if (split != null && split.Length > 0)
                    {
                        foreach (var sub in split)
                        {
                            result.Add(new Slab(sub, slab.Thickness, slab.Level));
                        }
                    }
                    else
                    {
                        result.Add(slab);
                    }
                }
            }

            return result;
        }
        public static List<Slab> GenerateSlabsBetweenPoints(List<Point3d> points, double xSpacing, double ySpacing, double tolerance = 0.001)
        {
            var slabs = new List<Slab>();

            // Gruppér punktene etter Z-nivå og hopp over det laveste nivået (fundament)
            var levels = points
                .GroupBy(p => Math.Round(p.Z / tolerance) * tolerance)
                .OrderBy(g => g.Key)
                .Skip(1);  // Skipper første (laveste) nivå

            foreach (var level in levels)
            {
                var pts = level.ToList();

                // Gruppér etter Y for X-retning
                var yGroups = pts.GroupBy(p => Math.Round(p.Y / tolerance) * tolerance).ToList();

                for (int yg = 0; yg < yGroups.Count - 1; yg++)
                {
                    var currentYGroup = yGroups[yg].OrderBy(p => p.X).ToList();
                    var nextYGroup = yGroups[yg + 1].OrderBy(p => p.X).ToList();

                    int count = Math.Min(currentYGroup.Count, nextYGroup.Count) - 1;
                    for (int i = 0; i < count; i++)
                    {
                        var p1 = currentYGroup[i];
                        var p2 = currentYGroup[i + 1];
                        var p3 = nextYGroup[i + 1];
                        var p4 = nextYGroup[i];

                        if (p1.DistanceTo(p2) > xSpacing * 1.1 || p1.DistanceTo(p4) > ySpacing * 1.1)
                            continue; // Hopper over hvis punktene ikke matcher gridet

                        var slabSurface = NurbsSurface.CreateFromCorners(p1, p2, p3, p4);
                        if (slabSurface != null)
                            slabs.Add(new Slab(slabSurface.ToBrep(), 0.2, p1.Z));  // 0.2 = tykkelse
                    }
                }
            }

            return slabs;
        }
        public static List<Slab> GenerateSlabsGP(
    List<Point3d> totalPts,
    List<Brep> brepsInput,
    double defaultThickness = 0.2,
    double tolerance = 1e-6)
        {
            var slabs = new List<Slab>();

            // Gruppér punktene i horisontale lag etter Z‐verdi
            var layers = totalPts
              .GroupBy(p => Math.Round(p.Z / tolerance) * tolerance)
              .OrderBy(g => g.Key)
              .ToList();

            // Skipp grunnlaget
            if (layers.Count < 2) return slabs;
            var upperLayers = layers.Skip(1);

            foreach (var layer in upperLayers)
            {
                double z = layer.Key;
                var pts2d = layer.ToList();

                // Unike X- og Y-koord
                var xs = pts2d.Select(p => p.X).Distinct().OrderBy(x => x).ToList();
                var ys = pts2d.Select(p => p.Y).Distinct().OrderBy(y => y).ToList();

                // Hver rute i grid
                for (int i = 0; i < xs.Count - 1; i++)
                {
                    for (int j = 0; j < ys.Count - 1; j++)
                    {
                        var p00 = new Point3d(xs[i], ys[j], z);
                        var p10 = new Point3d(xs[i + 1], ys[j], z);
                        var p11 = new Point3d(xs[i + 1], ys[j + 1], z);
                        var p01 = new Point3d(xs[i], ys[j + 1], z);

                        // Lag planar ramme
                        var pl = new Polyline(new[] { p00, p10, p11, p01, p00 });
                        var curve = pl.ToNurbsCurve();
                        var brepArr = Brep.CreatePlanarBreps(curve, tolerance);

                        if (brepArr == null || brepArr.Length == 0) continue;

                        var slabBrep = brepArr[0];

                        // Sjekk om slab‐senter ligger inne i en av input‐brepene
                        var amp = AreaMassProperties.Compute(slabBrep);
                        if (amp == null) continue;
                        var centroid = amp.Centroid;
                        bool insideAny = brepsInput
                            .Any(b => b.IsPointInside(centroid, tolerance, false));

                        if (!insideAny)
                            continue;

                        // Legg til som Slab‐objekt
                        slabs.Add(new Slab(slabBrep, defaultThickness, z));
                    }
                }
            }

            return slabs;
        }
        public static List<Slab> GenerateSlabsFromPoints(
            List<Point3d> totalPts,
            double defaultThickness = 0.2,
            double tolerance = 1e-6)
        {
            var slabs = new List<Slab>();

            // Group points by Z-level
            var levels = totalPts
                .GroupBy(p => Math.Round(p.Z / tolerance) * tolerance)
                .OrderBy(g => g.Key)
                .ToList();

            // Need at least two levels to form slabs
            if (levels.Count < 2) return slabs;

            // Skip the lowest level (foundation)
            foreach (var level in levels.Skip(1))
            {
                double z = level.Key;
                var pts2d = level.ToList();

                // Extract distinct X and Y coordinates
                var xs = pts2d.Select(p => p.X).Distinct().OrderBy(x => x).ToList();
                var ys = pts2d.Select(p => p.Y).Distinct().OrderBy(y => y).ToList();

                // For each cell in the grid, form the four corner points
                for (int i = 0; i < xs.Count - 1; i++)
                {
                    for (int j = 0; j < ys.Count - 1; j++)
                    {
                        var p00 = new Point3d(xs[i], ys[j], z);
                        var p10 = new Point3d(xs[i + 1], ys[j], z);
                        var p11 = new Point3d(xs[i + 1], ys[j + 1], z);
                        var p01 = new Point3d(xs[i], ys[j + 1], z);

                        // Verify these corner points exist in the grid
                        bool exists00 = pts2d.Any(p => Math.Abs(p.X - p00.X) < tolerance && Math.Abs(p.Y - p00.Y) < tolerance);
                        bool exists10 = pts2d.Any(p => Math.Abs(p.X - p10.X) < tolerance && Math.Abs(p.Y - p10.Y) < tolerance);
                        bool exists11 = pts2d.Any(p => Math.Abs(p.X - p11.X) < tolerance && Math.Abs(p.Y - p11.Y) < tolerance);
                        bool exists01 = pts2d.Any(p => Math.Abs(p.X - p01.X) < tolerance && Math.Abs(p.Y - p01.Y) < tolerance);
                        if (!exists00 || !exists10 || !exists11 || !exists01) continue;

                        // Create planar polyline and Brep
                        var poly = new Polyline(new[] { p00, p10, p11, p01, p00 });
                        var curve = poly.ToNurbsCurve();
                        var breps = Brep.CreatePlanarBreps(curve, tolerance);
                        if (breps == null || breps.Length == 0) continue;

                        // Wrap as Slab with thickness
                        var brepSlab = breps[0];
                        slabs.Add(new Slab(brepSlab, defaultThickness, z));
                    }
                }
            }
            return slabs;
        }
    }
}
