﻿using System;
using System.Collections.Generic;
using Alg1.Models;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using Rhino.Geometry;

namespace Alg1
{
    public class Deconstructbuilding2 : GH_Component
    {
        
        public Deconstructbuilding2()
          : base("Deconstructbuilding2", "Nickname",
              "Description",
              "Category", "Subcategory")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "b", "Input building object", GH_ParamAccess.item);
        }

        
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddCurveParameter("Columns", "cs", "Extracted column lines", GH_ParamAccess.list);
            pManager.AddCurveParameter("Beams", "bs", "Extracted beam lines", GH_ParamAccess.tree);
            pManager.AddBrepParameter("Slabs", "ss", "Extracted slab geometries", GH_ParamAccess.list);
            pManager.AddCurveParameter("InternalBeams", "Ibb", "Internal beam curves", GH_ParamAccess.tree);
            pManager.AddCurveParameter("EdgeBeams", "Ebb", "Edge beam curves", GH_ParamAccess.tree);
            pManager.AddCurveParameter("SecondaryBeams", "Sbb", "Secondary beam curves", GH_ParamAccess.tree);
        }

        
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            Building building = null;
            if (!DA.GetData(0, ref building) || building == null)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Invalid or null Building object.");
                return;
            }

            // 1) Columns
            var cols = new List<Curve>();
            if (building.Columns != null)
            {
                foreach (var column in building.Columns)
                {
                    if (column.Axis != null && column.Axis.IsValid)
                        cols.Add(column.Axis.DuplicateCurve());
                }
            }


            // 2) Slabs
            var slbs = new List<Brep>();
            if (building.Slabs != null)
            {
                foreach (var slab in building.Slabs)
                {
                    if (slab.Geometry != null && slab.Geometry.IsValid)
                        slbs.Add(slab.Geometry);
                }
            }

            // 3) Beam‐trees
            var allBeamsTree = new GH_Structure<GH_Curve>();
            var internalBeamsTree = new GH_Structure<GH_Curve>();
            var edgeBeamsTree = new GH_Structure<GH_Curve>();
            var secondaryBeamsTree = new GH_Structure<GH_Curve>();

            
            if (building.BeamSublists != null)
            {
                for (int i = 0; i < building.BeamSublists.Count; i++)
                {
                    var subList = building.BeamSublists[i];
                    var path = new GH_Path(i);

                    foreach (var beamObj in subList)
                    {
                        
                        if (beamObj.Axis != null && beamObj.Axis.IsValid)
                        {
                            var ghc = new GH_Curve(beamObj.Axis);

                            
                            allBeamsTree.Append(ghc, path);

                            
                            switch (i)
                            {
                                case 0:
                                    internalBeamsTree.Append(ghc, path);
                                    break;
                                case 1:
                                    edgeBeamsTree.Append(ghc, path);
                                    break;
                                case 2:
                                    secondaryBeamsTree.Append(ghc, path);
                                    break;
                            }
                        }
                    }
                }
            }

            
            DA.SetDataList(0, cols);
            DA.SetDataTree(1, allBeamsTree);
            DA.SetDataList(2, slbs);
            DA.SetDataTree(3, internalBeamsTree);
            DA.SetDataTree(4, edgeBeamsTree);
            DA.SetDataTree(5, secondaryBeamsTree);
        }

        
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("02A29775-BD11-4DB2-BD4D-FD5D6BEEA4D6"); }
        }
    }
}