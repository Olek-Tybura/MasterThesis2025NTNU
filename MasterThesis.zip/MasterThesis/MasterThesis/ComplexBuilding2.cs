﻿using System;
using System.Collections.Generic;
using System.Linq;
using Grasshopper.Kernel;
using Rhino.Geometry;
using Alg1.Models;
using Rhino.Collections;

namespace Alg1
{
    public class ComplexBuilding2 : GH_Component
    {
        
        public ComplexBuilding2()
          : base("ComplexBuilding2", "Nickname",
              "Description",
              "Category", "Subcategory")
        {
        }

        
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddCurveParameter("BaseCurve", "C", "Lukket planar kurve for fotavtrykk", GH_ParamAccess.item);
            pManager.AddNumberParameter("Rotation per floor", "R", "Twist angle in degrees", GH_ParamAccess.item, 0.0);
            pManager.AddNumberParameter("Floor Height", "H", "Height per floor", GH_ParamAccess.item, 3.0);
            pManager.AddIntegerParameter("Floors", "F", "Number of floors", GH_ParamAccess.item, 10);
            pManager.AddNumberParameter("Inset Dist", "I", "Inward offset for columns (meters)", GH_ParamAccess.item, 2.0);
        }

        
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "B", "Generated building object", GH_ParamAccess.item);
        }

        
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            Curve baseCurve = null;
            double rotDeg = 0.0;
            double floorHeight = 3.0;
            int floors = 10;
            double insetDist = 2.0;
            if (!DA.GetData(0, ref baseCurve)) return;
            if (!DA.GetData(1, ref rotDeg)) return;
            if (!DA.GetData(2, ref floorHeight)) return;
            if (!DA.GetData(3, ref floors)) return;
            if (!DA.GetData(4, ref insetDist)) return;

            // — Valider baseCurve —
            if (!baseCurve.IsClosed || !baseCurve.IsPlanar())
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error,
                    "BaseCurve må være lukket og plan.");
                return;
            }

            // — Finn rotasjonssenter —
            var amp = AreaMassProperties.Compute(baseCurve);
            if (amp == null)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error,
                    "Kunne ikke beregne sentrum for BaseCurve.");
                return;
            }
            Point3d centre = new Point3d(amp.Centroid.X, amp.Centroid.Y, 0);

            // — Parametre og Building —
            double rotRad = Rhino.RhinoMath.ToRadians(rotDeg);
            double tol = Rhino.RhinoDoc.ActiveDoc.ModelAbsoluteTolerance;
            var building = new Building("TwistingTower", 1)
            {
                BeamSublists = new List<List<Beam>>
        {
            new List<Beam>(),  // Internal (tom)
            new List<Beam>(),  // Edge   ← her legger vi ringbjelker
            new List<Beam>()   // Secondary (tom)
        }
            };

            // — Hent hjørner i ytterkant for bjelker/slabs —
            var outerCorners = GetCornerPoints(baseCurve);
            if (outerCorners.Count == 0)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error,
                    "Kunne ikke finne hjørner på BaseCurve.");
                return;
            }

            // — Offset innad for kolonner (uendret) —
            Curve[] innerCurves = baseCurve.Offset(
                Plane.WorldXY, -insetDist, tol, CurveOffsetCornerStyle.Sharp
            );
            if (innerCurves == null || innerCurves.Length == 0) return;
            var innerCorners = GetCornerPoints(innerCurves[0]);

            // — Kolonner per etasje (uendret) —
            for (int lvl = 1; lvl <= floors; lvl++)
            {
                double z0 = (lvl - 1) * floorHeight;
                double z1 = lvl * floorHeight;
                foreach (var pt in innerCorners)
                    building.Columns.Add(
                      new Column(new LineCurve(
                        new Point3d(pt.X, pt.Y, z0),
                        new Point3d(pt.X, pt.Y, z1)
                      ))
                    );
            }

            // — Slabs & **kun** ringbjelker (edge) —
            for (int lvl = 1; lvl <= floors; lvl++)
            {
                // a) Transform for dette nivå
                var rot = Transform.Rotation(lvl * rotRad, Vector3d.ZAxis, centre);
                var xlat = Transform.Translation(0, 0, lvl * floorHeight);

                // b) Slab
                var slabCrv = baseCurve.DuplicateCurve();
                slabCrv.Transform(rot);
                slabCrv.Transform(xlat);
                var breps = Brep.CreatePlanarBreps(slabCrv, tol);
                if (breps?.Length > 0)
                    building.Slabs.Add(new Slab(breps[0]));

                // c) Ringbjelker: sublist[1]
                for (int j = 0; j < outerCorners.Count; j++)
                {
                    var p0 = outerCorners[j];
                    var p1 = outerCorners[(j + 1) % outerCorners.Count];
                    p0.Transform(rot); p0.Transform(xlat);
                    p1.Transform(rot); p1.Transform(xlat);
                    building.BeamSublists[1].Add(new Beam(new LineCurve(p0, p1)));
                }
            }

            // — Output —
            DA.SetData(0, building);
        }
        private List<Point3d> GetCornerPoints(Curve curve)
        {
            if (!curve.TryGetPolyline(out Polyline pl))
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, "Kunne ikke lage polyline.");
                return new List<Point3d>();
            }

            // RhinoList<Point3d> inneholder alle hjørnepunktene
            RhinoList<Point3d> rhPoints = pl.GetRange(0, pl.Count - 1);

            // Konverter til vanlig List<Point3d>
            return new List<Point3d>(rhPoints);
        }


        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                
                return null;
            }
        }

        
        public override Guid ComponentGuid
        {
            get { return new Guid("5E35FEC2-010B-487F-AC8C-D455CDDFA767"); }
        }
    }
}