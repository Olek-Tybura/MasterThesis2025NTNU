﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using Rhino.Geometry;
using Alg1.Models;

namespace Alg1
{
    public class DeconstructBuilding : GH_Component
    {
        
        public DeconstructBuilding()
          : base("DeconstructBuilding", "Nickname",
              "Description",
              "Category", "Deconstruct")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "b", "Input building object", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddCurveParameter("Columns", "cs", "Extracted column lines", GH_ParamAccess.list);
            pManager.AddCurveParameter("Beams", "bs", "Extracted beam lines", GH_ParamAccess.tree);
            pManager.AddBrepParameter("Slabs", "ss", "Extracted slab geometries", GH_ParamAccess.list);
            pManager.AddCurveParameter("InternalBeams", "Ibb", "Internal beam curves", GH_ParamAccess.tree);
            pManager.AddCurveParameter("EdgeBeams", "Ebb", "Edge beam curves", GH_ParamAccess.tree);
            pManager.AddCurveParameter("SecondaryBeams", "Sbb", "Secondary beam curves", GH_ParamAccess.tree);
            pManager.AddCurveParameter("Bracings", "br", "Extracted bracing lines", GH_ParamAccess.list);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // Try to get the Building object from the input
            Building building = null;
            if (!DA.GetData(0, ref building) || building == null)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Invalid or null Building object.");
                return;
            }

            // Lists to store extracted elements
            List<Line> cols = new List<Line>();
            List<Line> bms = new List<Line>();
            List<Brep> slbs = new List<Brep>();

            // Convert Columns to Curve (LineCurve)
            
            if (building.Columns != null && building.Columns.Count > 0)
            {
                foreach (var column in building.Columns)
                {
                    if (column.Axis != null && column.Axis.IsValid)
                        cols.Add(column.Axis);
                }
            }




            // Extract Slab Breps
            if (building.Slabs != null && building.Slabs.Count > 0)
            {
                foreach (var slab in building.Slabs)
                {
                    if (slab.Geometry != null && slab.Geometry.IsValid)
                        slbs.Add(slab.Geometry);
                }
            }
            Grasshopper.Kernel.Data.GH_Structure<GH_Line> beamSubTree = new GH_Structure<GH_Line>();
            if (building.BeamSublists != null && building.BeamSublists.Count > 0)
            {
                for (int i = 0; i < building.BeamSublists.Count; i++)
                {
                    GH_Path branchPath = new GH_Path(i);
                    foreach (Beam beam in building.BeamSublists[i])
                    {
                        if (beam.Axis.IsValid)
                        {
                            // Convert beam's underlying Line to a LineCurve, then wrap in GH_Curve.
                            beamSubTree.Append(new GH_Line(beam.Axis), branchPath);
                        }
                    }
                }
            }

            GH_Structure<GH_Line> internalTree = new GH_Structure<GH_Line>();
            GH_Structure<GH_Line> edgeTree = new GH_Structure<GH_Line>();
            GH_Structure<GH_Line> secondaryTree = new GH_Structure<GH_Line>();
            if (building.BeamSublists != null && building.BeamSublists.Count >= 3)
            {
                // For internal beams (assumed index 0)
                GH_Path internalPath = new GH_Path(0);
                foreach (Beam beam in building.BeamSublists[0])
                {
                    if (beam.Axis.IsValid)
                        internalTree.Append(new GH_Line(beam.Axis), internalPath);
                }
                // For edge beams (assumed index 1)
                GH_Path edgePath = new GH_Path(0);
                foreach (Beam beam in building.BeamSublists[1])
                {
                    if (beam.Axis.IsValid)
                        edgeTree.Append(new GH_Line(beam.Axis), edgePath);
                }
                // For secondary beams (assumed index 2)
                GH_Path secondaryPath = new GH_Path(0);
                foreach (Beam beam in building.BeamSublists[2])
                {
                    if (beam.Axis.IsValid)
                        secondaryTree.Append(new GH_Line(beam.Axis), secondaryPath);
                }
            }
            else
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Warning, "Building does not contain beam sublists for all three beam types.");
            }

            List<Curve> brcs = new List<Curve>();
            if (building.Bracings != null && building.Bracings.Count > 0)
            {
                foreach (var bracing in building.Bracings)
                {
                    if (bracing.Axis.IsValid)
                        brcs.Add(new LineCurve(bracing.Axis));
                }
            }

            // Output the extracted data
            DA.SetDataList(0, cols);
            DA.SetDataTree(1, beamSubTree);
            DA.SetDataList(2, slbs);
            DA.SetDataTree(3, internalTree);
            DA.SetDataTree(4, edgeTree);
            DA.SetDataTree(5, secondaryTree);
            DA.SetDataList(6, brcs);
        }

        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("E1DD853B-880A-4082-BD4D-2B1F669D1803"); }
        }
    }
}