﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;
using Alg1.Models;

namespace Alg1
{
    public class ComplexBuilding : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the ComplexBuilding class.
        /// </summary>
        public ComplexBuilding()
          : base("ComplexBuilding", "Nickname",
              "Description",
              "Category", "Subcategory")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddCurveParameter("Base Curve", "C", "Closed base curve for footprint", GH_ParamAccess.item);
            pManager.AddIntegerParameter("Floors", "F", "Number of floors", GH_ParamAccess.item, 10);
            pManager.AddNumberParameter("Floor Height", "H", "Height per floor", GH_ParamAccess.item, 3.4);
            pManager.AddNumberParameter("Twist Angle", "T", "Total twist angle (degrees)", GH_ParamAccess.item, 90.0);
            pManager.AddNumberParameter("Spacing", "S", "Grid spacing (approx)", GH_ParamAccess.item, 6.0);
            pManager.AddIntegerParameter("Column Mode", "M", "0 = circular (grid columns), 1 = corner columns only", GH_ParamAccess.item, 0);
        }

        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "B", "Generated twisting building", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            Curve baseCrv = null;
            int floors = 10, columnMode = 0;
            double floorHeight = 3.4, twistDeg = 90.0, spacing = 6.0;

            if (!DA.GetData(0, ref baseCrv)) return;
            DA.GetData(1, ref floors);
            DA.GetData(2, ref floorHeight);
            DA.GetData(3, ref twistDeg);
            DA.GetData(4, ref spacing);
            DA.GetData(5, ref columnMode);

            if (!baseCrv.IsClosed || !baseCrv.IsPlanar())
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error, "Input curve must be planar and closed.");
                return;
            }

            var building = new Building();
            building.BeamSublists = new List<List<Beam>>
            {
                new List<Beam>(),  // Internal
                new List<Beam>(),  // Edge
                new List<Beam>()   // Secondary
            };

            double twistPerFloor = twistDeg / floors;
            Point3d center = AreaMassProperties.Compute(baseCrv).Centroid;

            List<Point3d> cornerPoints = null;
            Polyline polyline;
            if (baseCrv.TryGetPolyline(out polyline) && polyline.Count >= 4)
            {
                cornerPoints = new List<Point3d>(polyline);
                if (cornerPoints[0].DistanceTo(cornerPoints[cornerPoints.Count - 1]) < 1e-6)
                    cornerPoints.RemoveAt(cornerPoints.Count - 1);
            }

            for (int i = 0; i <= floors; i++)
            {
                double z = i * floorHeight;
                double nextZ = (i + 1) * floorHeight;

                double lowerAngle = Rhino.RhinoMath.ToRadians(i * twistPerFloor);
                double upperAngle = Rhino.RhinoMath.ToRadians((i + 1) * twistPerFloor);

                if (columnMode == 0)
                {
                    // unchanged grid mode
                }
                else if (columnMode == 1 && cornerPoints != null)
                {
                    List<Point3d> lowerCorners = new List<Point3d>();
                    List<Point3d> upperCorners = new List<Point3d>();
                    List<Point3d> lowerEdgeCenters = new List<Point3d>();
                    List<Point3d> upperEdgeCenters = new List<Point3d>();

                    for (int j = 0; j < cornerPoints.Count; j++)
                    {
                        Point3d corner = cornerPoints[j];
                        Point3d nextCorner = cornerPoints[(j + 1) % cornerPoints.Count];
                        Point3d mid = 0.5 * (corner + nextCorner);

                        Point3d lowerCorner = new Point3d(corner.X, corner.Y, z);
                        lowerCorner.Transform(Transform.Rotation(lowerAngle, Vector3d.ZAxis, new Point3d(center.X, center.Y, z)));
                        lowerCorners.Add(lowerCorner);

                        Point3d upperCorner = new Point3d(corner.X, corner.Y, nextZ);
                        upperCorner.Transform(Transform.Rotation(upperAngle, Vector3d.ZAxis, new Point3d(center.X, center.Y, nextZ)));
                        upperCorners.Add(upperCorner);

                        building.Columns.Add(new Column(new Line(lowerCorner, upperCorner)));

                        Point3d lowerMid = new Point3d(mid.X, mid.Y, z);
                        lowerMid.Transform(Transform.Rotation(lowerAngle, Vector3d.ZAxis, center));
                        lowerEdgeCenters.Add(lowerMid);

                        Point3d upperMid = new Point3d(mid.X, mid.Y, nextZ);
                        upperMid.Transform(Transform.Rotation(upperAngle, Vector3d.ZAxis, center));
                        upperEdgeCenters.Add(upperMid);

                        building.Columns.Add(new Column(new Line(lowerMid, upperMid)));
                    }

                    int cornerCount = lowerCorners.Count;
                    if (i > 0 && i < floors)
                    {
                        for (int j = 0; j < cornerCount; j++)
                        {
                            var lb1 = new Beam(new Line(lowerCorners[j], lowerEdgeCenters[j]));
                            var lb2 = new Beam(new Line(lowerEdgeCenters[j], lowerCorners[(j + 1) % cornerCount]));
                            building.Beams.Add(lb1);
                            building.Beams.Add(lb2);
                            building.BeamSublists[1].Add(lb1);
                            building.BeamSublists[1].Add(lb2);

                            //var ub1 = new Beam(new Line(upperCorners[j], upperEdgeCenters[j]));
                            //var ub2 = new Beam(new Line(upperEdgeCenters[j], upperCorners[(j + 1) % cornerCount]));
                            //building.Beams.Add(ub1);
                            //building.Beams.Add(ub2);
                            //building.BeamSublists[1].Add(ub1);
                            //building.BeamSublists[1].Add(ub2);
                        }

                        Point3d lowerCenter = new Point3d(center.X, center.Y, z);
                        lowerCenter.Transform(Transform.Rotation(lowerAngle, Vector3d.ZAxis, center));
                        Point3d upperCenter = new Point3d(center.X, center.Y, nextZ);
                        upperCenter.Transform(Transform.Rotation(upperAngle, Vector3d.ZAxis, center));
                        building.Columns.Add(new Column(new Line(lowerCenter, upperCenter)));

                        List<Point3d> lowerAll = new List<Point3d>(lowerCorners);
                        lowerAll.AddRange(lowerEdgeCenters);
                        List<Point3d> upperAll = new List<Point3d>(upperCorners);
                        upperAll.AddRange(upperEdgeCenters);

                        for (int j = 0; j < lowerAll.Count; j++)
                        {
                            var beam = new Beam(new Line(lowerAll[j], lowerCenter));
                            building.Beams.Add(beam);
                            building.BeamSublists[0].Add(beam);

                           var beamUpper = new Beam(new Line(upperAll[j], upperCenter));
                            building.Beams.Add(beamUpper);
                            building.BeamSublists[0].Add(beamUpper);
                        }
                    }
                }

                if (i > 0)
                {
                    Curve slabCrv = baseCrv.DuplicateCurve();
                    slabCrv.Translate(Vector3d.ZAxis * z);
                    double angle = Rhino.RhinoMath.ToRadians(i * twistPerFloor);
                    Transform rotation = Transform.Rotation(angle, Vector3d.ZAxis, new Point3d(center.X, center.Y, z));
                    slabCrv.Transform(rotation);

                    double tol = Rhino.RhinoDoc.ActiveDoc.ModelAbsoluteTolerance;
                    var brepSlabs = Brep.CreatePlanarBreps(slabCrv, tol);

                    if (brepSlabs != null && brepSlabs.Length > 0)
                        building.Slabs.Add(new Slab(brepSlabs[0], 0.0, z));
                }
            }

            double topZ = floors * floorHeight;
            Curve topSlabCrv = baseCrv.DuplicateCurve();
            topSlabCrv.Translate(Vector3d.ZAxis * topZ);
            double finalAngle = Rhino.RhinoMath.ToRadians(floors * twistPerFloor);
            Transform finalRotation = Transform.Rotation(finalAngle, Vector3d.ZAxis, new Point3d(center.X, center.Y, topZ));
            topSlabCrv.Transform(finalRotation);
            double topTol = Rhino.RhinoDoc.ActiveDoc.ModelAbsoluteTolerance;
            var topSlabs = Brep.CreatePlanarBreps(topSlabCrv, topTol);
            if (topSlabs != null && topSlabs.Length > 0)
                building.Slabs.Add(new Slab(topSlabs[0], 0.0, topZ));

            DA.SetData(0, building);
        }
        

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("29FF01D2-80E3-4E82-8D4E-74BA05CB50EA"); }
        }
    }
}