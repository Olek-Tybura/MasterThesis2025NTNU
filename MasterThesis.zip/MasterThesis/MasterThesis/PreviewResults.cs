﻿using System;
using System.Collections.Generic;
using System.Linq;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using Rhino.Geometry;

namespace Alg1
{
    public class PreviewResults : GH_Component
    {
       
        public PreviewResults()
          : base("PreviewResults", "Nickname",
              "Calculates volumes and sorts the inputs ofr further analysis",
              "Category", "Analysis")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddIntegerParameter("BuildingType", "BT", "1=HD+Steel, 2=CLT+Gluelam, 3=CastConcrete", GH_ParamAccess.item);
            pManager.AddTextParameter("BeamIDs", "ID", "IDs av bjelker og søyler", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamLengths", "L", "Lengder av bjelker/søyler [m]", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamAreas", "A", "Tverrsnittsareal per element [cm²]", GH_ParamAccess.list);
            pManager.AddNumberParameter("SlabAreas", "SlabA", "Planareal dekker [m²]", GH_ParamAccess.list);
            pManager.AddNumberParameter("SlabThickness", "SlabT", "Tykkelse dekker [cm] (tre-tree)", GH_ParamAccess.tree);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            // 0…4 brukes som input til CostCalculator
            pManager.AddIntegerParameter("BuildingType", "BT", "1, 2 eller 3", GH_ParamAccess.item);
            pManager.AddTextParameter("BeamIDs", "ID", "Alle beam/column-IDer", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamLengths", "L", "Lengde per element [m]", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamAreas", "A", "Tverrsnittsareal per element [cm²]", GH_ParamAccess.list);

            // 5–9 volum/areal verdier
            pManager.AddNumberParameter("VolumeColumns", "VolCols", "Volum søyler [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeBeams", "VolBms", "Volum bjelker [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeSlabs", "VolSlabs", "Volum dekker [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("AreaSlabs", "SlabA", "Sum planareal alle dekker [m²]", GH_ParamAccess.item);
            pManager.AddTextParameter("HDProfile", "HDProf", "Valgt hulldekke-profil (HD200, HD265, …)", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // 1) Les inn
            int bt = 0;
            if (!DA.GetData(0, ref bt)) return;

            var ids = new List<string>();
            var lengths = new List<double>();
            var areasCm2 = new List<double>();
            var slabAreas = new List<double>();
            var slabTree = new GH_Structure<GH_Number>();

            if (!DA.GetDataList(1, ids)) return;
            if (!DA.GetDataList(2, lengths)) return;
            if (!DA.GetDataList(3, areasCm2)) return;
            if (!DA.GetDataList(4, slabAreas)) return;
            if (!DA.GetDataTree(5, out slabTree)) return;

            // 2) Valider at beam-listene synkroniserer
            if (ids.Count != lengths.Count ||
                ids.Count != areasCm2.Count)
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error,
                    "BeamIDs, BeamLengths og BeamAreas må ha samme antall items.");
                return;
            }

            // 3) Konverter areal fra cm² → m²
            var areas = areasCm2.Select(a => a / 10000.0).ToList();

            // 4) Flatten slab-tykkelser (BT≠1)
            List<double> slabThs = null;
            if (bt != 1)
            {
                slabThs = slabTree
                  .FlattenData()
                  .Select(n => n.Value / 100.0)
                  .ToList();
                if (slabThs.Count == 1)
                    slabThs = Enumerable.Repeat(slabThs[0], slabAreas.Count).ToList();
                if (slabThs.Count != slabAreas.Count)
                {
                    AddRuntimeMessage(GH_RuntimeMessageLevel.Error,
                        "SlabThickness må være én verdi eller like mange som SlabAreas for BT2/3.");
                    return;
                }
            }

            // 5) Volum søyler & bjelker
            double volCols = 0, volBms = 0;
            for (int i = 0; i < ids.Count; i++)
            {
                double v = areas[i] * lengths[i];
                if (ids[i].IndexOf("col", StringComparison.OrdinalIgnoreCase) >= 0)
                    volCols += v;
                else
                    volBms += v;
            }

            // 6) Volum dekker
            double volSlabs = 0;
            for (int i = 0; i < slabAreas.Count; i++)
            {
                if (bt == 1)
                {
                    // HD-stripemetode
                    double span = DetermineHDSpan(ids, lengths);
                    double A_HD = GetHDProfileArea(span);
                    volSlabs += (slabAreas[i] / 1.2) * A_HD;
                }
                else
                {
                    // BT2/3: areal × tykkelse
                    volSlabs += slabAreas[i] * slabThs[i];
                }
            }

            // 7) Sum planareal
            double areaSum = slabAreas.Sum();

            // 8) HD-profilnavn
            double spanForProf = DetermineHDSpan(ids, lengths);
            string hdProf = spanForProf <= 10 ? "HD200"
                           : spanForProf <= 13 ? "HD265"
                           : spanForProf <= 15 ? "HD320"
                           : spanForProf <= 17 ? "HD400"
                           : "HD500";

            // 9) Returner alt
            DA.SetData(0, bt);
            DA.SetDataList(1, ids);
            DA.SetDataList(2, lengths);
            DA.SetDataList(3, areasCm2);
            DA.SetData(4, volCols);
            DA.SetData(5, volBms);
            DA.SetData(6, volSlabs);
            DA.SetData(7, areaSum);
            DA.SetData(8, hdProf);
        }
        private double DetermineHDSpan(List<string> ids, List<double> lengths)
        {
            var secLens = ids
              .Select((id, i) => new { id, len = lengths[i] })
              .Where(x => x.id.IndexOf("sec", StringComparison.OrdinalIgnoreCase) >= 0)
              .Select(x => x.len)
              .ToList();

            if (secLens.Count > 0)
            {
                // modus
                return secLens
                  .GroupBy(l => l)
                  .OrderByDescending(g => g.Count())
                  .First()
                  .Key;
            }
            // fallback: gjennomsnitt av alle
            return lengths.Average();
        }

        private double GetHDProfileArea(double span)
        {
            if (span <= 10) return 0.13;    // HD200
            if (span <= 13) return 0.17;    // HD265
            if (span <= 15) return 0.19;    // HD320
            if (span <= 17) return 0.22;    // HD400
            return 0.304;                   // HD500
        }


        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("582D9A09-331D-49E8-8CAE-9FBEEB9AD422"); }
        }
    }
}