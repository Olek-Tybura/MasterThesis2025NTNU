﻿using System;
using System.Collections.Generic;

using Grasshopper.Kernel;
using Rhino.Geometry;

namespace Alg1
{
    public class CostCalculator2 : GH_Component
    {
        /// <summary>
        /// Initializes a new instance of the CostCalculator2 class.
        /// </summary>
        public CostCalculator2()
          : base("CostCalculator2", "Nickname",
              "Calculates the cost of each structural elements, with addition of bracing costs",
              "Category", "Analysis")
        {
        }

        /// <summary>
        /// Registers all the input parameters for this component.
        /// </summary>
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            // 0: Building type selector (1 = HD + Steel, 2 = CLT + Glulam, 3 = Cast-In-Place Concrete)
            pManager.AddIntegerParameter("BuildingType", "BT", "1 = HD + Steel | 2 = CLT + Glulam | 3 = Cast-In-Place Concrete", GH_ParamAccess.item);

            // 1–5: Beam/column inputs from structural model
            pManager.AddTextParameter("BeamIDs", "ID", "List of beam/column IDs (used to distinguish elements)", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamLengths", "L", "Length of each beam/column [m]", GH_ParamAccess.list);
            pManager.AddNumberParameter("BeamAreas", "A", "Cross-sectional area of each element [cm²]", GH_ParamAccess.list);
            pManager.AddTextParameter("SectionTypeNames", "SecType", "Profile type name for each element", GH_ParamAccess.list);
            pManager.AddBooleanParameter("IsActiveBracing", "IsBr", "List of booleans matching BeamIDs: true if Bracing element is used", GH_ParamAccess.list);

            // 6: Hollow-core profile name (only relevant for BT1)
            pManager.AddTextParameter("HDProfile", "HDProf", "Hollow-core slab profile (HD200, HD265, …)", GH_ParamAccess.item);

            // 7: Concrete class selector (only relevant for BT3)
            pManager.AddIntegerParameter("ConcreteClass", "CC", "0=Standard, 1 = ClassA (+150 NOK/m³), 2=Extreme (+500 NOK/m³) (BT3 only)", GH_ParamAccess.item);
            pManager[6].Optional = true; // Defaults to 0 if not provided

            // 8–11: Aggregate volume and area from PreviewResults
            pManager.AddNumberParameter("VolumeColumns", "VolCols", "Total volume of columns [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeBeams", "VolBms", "Total volume of beams [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeSlabs", "VolSlabs", "Total volume of slabs [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("AreaSlabs", "SlabA", "Total plan area of slabs [m²]", GH_ParamAccess.item);
        }


        /// <summary>
        /// Registers all the output parameters for this component.
        /// </summary>
        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("CostColumns [NOK]", "CostCol", "Total cost for columns [NOK]", GH_ParamAccess.item);
            pManager.AddNumberParameter("CostBeams [NOK]", "CostBms", "Total cost for beams [NOK]", GH_ParamAccess.item);
            pManager.AddNumberParameter("CostSlabs [NOK]", "CostSlab", "Total cost for slabs [NOK]", GH_ParamAccess.item);
            pManager.AddNumberParameter("CostBracing [NOK]", "CostBracing", "Total cost for Cross-Bracing [NOK]", GH_ParamAccess.item);
            pManager.AddNumberParameter("TotalCost [NOK]", "CostTot", "Sum of all cost categories [NOK]", GH_ParamAccess.item);
        }

        /// <summary>
        /// This is the method that actually does the work.
        /// </summary>
        /// <param name="DA">The DA object is used to retrieve from inputs and store in outputs.</param>
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // 1) Read all input parameters
            int bt = 0;
            var ids = new List<string>();
            var lengths = new List<double>();
            var areasCm2 = new List<double>();
            var secTypes = new List<string>();
            var isActiveBracing = new List<bool>();
            string hdProf = "";
            int cc = 0;
            double volCols = 0.0, volBms = 0.0, volSlabs = 0.0, areaSlabs = 0.0;

            if (!DA.GetData(0, ref bt)) return;
            if (!DA.GetDataList(1, ids)) return;
            if (!DA.GetDataList(2, lengths)) return;
            if (!DA.GetDataList(3, areasCm2)) return;
            if (!DA.GetDataList(4, secTypes)) return;
            if (!DA.GetDataList(5, isActiveBracing)) return;
            if (!DA.GetData(6, ref hdProf)) return;
            DA.GetData(7, ref cc);    // Optional, defaults to 0
            if (!DA.GetData(8, ref volCols)) return;
            if (!DA.GetData(9, ref volBms)) return;
            if (!DA.GetData(10, ref volSlabs)) return;
            if (!DA.GetData(11, ref areaSlabs)) return;

            // 2) Validate input consistency
            if ((bt == 1 || bt == 2) &&
                (ids.Count != lengths.Count ||
                 ids.Count != areasCm2.Count ||
                 ids.Count != secTypes.Count ||
                 ids.Count != isActiveBracing.Count))
            {
                AddRuntimeMessage(GH_RuntimeMessageLevel.Error,
                    "All beam-related input lists must have the same length.");
                return;
            }


            // 3) Pricing & densities
            const double steelDensity = 7850.0;   // kg/m³ steel
            const double pricePerKgHEA = 40.0;     // NOK/kg S355 HEA
            const double pricePerKgBox = 49.0;     // NOK/kg cold-formed box
            const double pricePerKgCHS = 51.23;    // NOK/kg CHS
            const double pricePerKgBracing = 39.23; // NOK/kg (Bracing specific)

            const double pricePerM2HC = 1235.0;   // NOK/m² hollow-core slab
            const double pricePerM3Glulam = 38000.0;  // NOK/m³ GL32c glulam

            const double cltBase = 7800.0; // Base production cost for CLT [NOK/m³]
            const double cltT22Factor = 1.20; // 20% markup for T22 quality
            const double cltPricePerM3 = cltBase * cltT22Factor; // Final CLT cost used in the calculation

            const double pricePerM3ConcBase = 2635.0; // NOK/m³ B30 concrete
            const double factorB35 = 1.05;   // +5% surcharge for B35

            const double rebarKgPerM3 = 20.0 / 0.3; // ≈66.67 kg steel/m³ concrete
            const double pricePerKgRebar = 37.0;       // NOK/kg rebar

            const double priceFormworkM2 = 692.56;     // NOK/m² formwork for slabs


            // 4) Steel cost per meter
            double SteelCostPerMeter(double a_cm2, string prof, double priceOverride = 0)
            {
                double m2 = a_cm2 / 10000.0;
                double kgPm = m2 * steelDensity;
                double unit = priceOverride > 0 ? priceOverride :
                    prof.StartsWith("HEA", StringComparison.OrdinalIgnoreCase) ? pricePerKgHEA :
                    prof.StartsWith("CHS", StringComparison.OrdinalIgnoreCase) ? pricePerKgCHS : pricePerKgBox;
                return kgPm * unit;
            }

            // 5) Initialize cost variables
            double costCols = 0.0, costBms = 0.0, costSlabs = 0.0, costBracing = 0.0;

            // 6) Process each element
            for (int i = 0; i < ids.Count; i++)
            {
                string id = ids[i];
                double len = lengths[i];
                double area = areasCm2[i];
                string prof = secTypes[i];
                bool isBrace = id.IndexOf("Bracing", StringComparison.OrdinalIgnoreCase) >= 0;

                if (isBrace)
                {
                    if (i < isActiveBracing.Count && isActiveBracing[i])
                        costBracing += SteelCostPerMeter(area, prof, pricePerKgBracing) * len * 2.0; // Multiply bracing length by 2 to account for
                                                                                                     // double members per cross (X-shaped bracing),
                                                                                                     // although this is not visually represented in Karamba.
                    continue;
                }

                if (bt == 1 && id.IndexOf("col", StringComparison.OrdinalIgnoreCase) >= 0)
                    costCols += SteelCostPerMeter(area, prof) * len;
                else if (bt == 1)
                    costBms += SteelCostPerMeter(area, prof) * len;
            }

            // 7) Compute slabs depending on BT
            switch (bt)
            {
                case 1:
                    costSlabs = areaSlabs * pricePerM2HC;
                    break;
                case 2:
                    costCols += volCols * pricePerM3Glulam;
                    costBms += volBms * pricePerM3Glulam;
                    costSlabs = volSlabs * cltPricePerM3;
                    break;
                case 3:
                    double surcharge = cc == 1 ? 150.0 : cc == 2 ? 500.0 : 0.0;
                    double pricePerM3Conc = pricePerM3ConcBase + surcharge;
                    double priceConcCols = pricePerM3Conc * factorB35;

                    costCols = volCols * priceConcCols + volCols * rebarKgPerM3 * pricePerKgRebar;
                    costBms = volBms * priceConcCols + volBms * rebarKgPerM3 * pricePerKgRebar;

                    double concSlabCost = volSlabs * pricePerM3Conc;
                    double rebarSlabCost = volSlabs * rebarKgPerM3 * pricePerKgRebar;
                    double formworkSlabCost = areaSlabs * priceFormworkM2;
                    costSlabs = concSlabCost + rebarSlabCost + formworkSlabCost;
                    break;
            }

            // 8) Output all costs
            double total = costCols + costBms + costSlabs + costBracing;

            DA.SetData(0, costCols);
            DA.SetData(1, costBms);
            DA.SetData(2, costSlabs);
            DA.SetData(3, costBracing);
            DA.SetData(4, total);
        }
        

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("59E4E45E-CB78-495A-A816-C62364CB233E"); }
        }
    }
}