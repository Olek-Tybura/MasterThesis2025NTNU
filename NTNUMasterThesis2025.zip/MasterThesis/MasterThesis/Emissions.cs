﻿using System;
using System.Collections.Generic;
using System.Linq;
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using Rhino.Geometry;

namespace Alg1
{
    public class Emissions : GH_Component
    {
       
        public Emissions()
          : base("Emissions", "Nickname",
              "Calculates the CO2 emissions of each structural element",
              "Category", "Analysis")
        {
        }
        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            // 0. Building type
            pManager.AddIntegerParameter("BuildingType", "BT", "1=HD+Steel, 2=CLT+Gluelam, 3=CastConcrete", GH_ParamAccess.item);

            // 1–3. Volumes
            pManager.AddNumberParameter("VolumeColumns", "VolCols", "Total volume of columns [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeBeams", "VolBms", "Total volume of beams [m³]", GH_ParamAccess.item);
            pManager.AddNumberParameter("VolumeSlabs", "VolSlabs", "Total volume of slabs [m³]", GH_ParamAccess.item);

            // 4. Concrete class selector (BT3 only)
            pManager.AddIntegerParameter("ConcreteClass", "CC", "0=Standard, 1=ClassA, 2=Extreme (BT3 only)", GH_ParamAccess.item);
            pManager[4].Optional = true; // if not connected → cc = 0
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddNumberParameter("Column CO₂-eq [kg]", "Col", "Total CO₂-equivalents for columns [kg]", GH_ParamAccess.item);
            pManager.AddNumberParameter("Beam   CO₂-eq [kg]", "Beam", "Total CO₂-equivalents for beams [kg]", GH_ParamAccess.item);
            pManager.AddNumberParameter("Slab   CO₂-eq [kg]", "Slab", "Total CO₂-equivalents for slabs [kg]", GH_ParamAccess.item);
            pManager.AddNumberParameter("Total CO₂-eq [kg]", "Tot", "Sum of all categories [kg]", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            // 1) Retrieve inputs
            int bt = 0;
            double vC = 0.0, vB = 0.0, vS = 0.0;
            int cc = 0;

            if (!DA.GetData(0, ref bt)) return;
            if (!DA.GetData(1, ref vC)) return;
            if (!DA.GetData(2, ref vB)) return;
            if (!DA.GetData(3, ref vS)) return;
            DA.GetData(4, ref cc);  // optional: if not connected, cc = 0

            // 2) Standard EPD factors [kg CO₂-eq per m³]
            const double E_CLT = -614.0;   // CLT slabs
            const double E_GL = -726.0;   // Glulam beams/columns
            const double E_CSlab = 195.243;  // Cast concrete slabs
            const double E_CBeam = 200.494;  // Cast concrete beams/columns
            const double E_HC = 126.771;  // Hollow-core slabs
            const double E_ST = 8988.25;  // Structural steel elements

            // 3) Class A (low-carbon) surcharges [kg CO₂-eq per m³]
            const double E_CSlab_A = 150.0;   // Class A concrete slabs
            const double E_CBeam_A = 160.0;   // Class A concrete beams/columns

            // 4) Extreme (ultra low-carbon) factors [kg CO₂-eq per m³]
            const double E_CSlab_X = 100.0;   // Extreme concrete slabs
            const double E_CBeam_X = 120.0;   // Extreme concrete beams/columns

            // 5) Select factor per category
            double fCol, fBeam, fSlab;
            if (bt == 1) // HD + steel
            {
                fCol = E_ST;
                fBeam = E_ST;
                fSlab = E_HC;
            }
            else if (bt == 2) // CLT + glulam
            {
                fCol = E_GL;
                fBeam = E_GL;
                fSlab = E_CLT;
            }
            else // bt == 3: Cast-in-place concrete
            {
                // choose standard / Class A / Extreme
                fCol = (cc == 0) ? E_CBeam : (cc == 1) ? E_CBeam_A : E_CBeam_X;
                fBeam = (cc == 0) ? E_CBeam : (cc == 1) ? E_CBeam_A : E_CBeam_X;
                fSlab = (cc == 0) ? E_CSlab : (cc == 1) ? E_CSlab_A : E_CSlab_X;
            }

            // 6) Compute CO₂-eq per category
            double colCo2 = vC * fCol;
            double beamCo2 = vB * fBeam;
            double slabCo2 = vS * fSlab;

            // 7) Sum total
            double total = colCo2 + beamCo2 + slabCo2;

            // 8) Return results
            DA.SetData(0, colCo2);
            DA.SetData(1, beamCo2);
            DA.SetData(2, slabCo2);
            DA.SetData(3, total);
        }
        // Returns hollow-core cross-sectional area [m²] based on span length
        
        

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("39E12358-79CA-4BC0-8488-F60EEEDC5E15"); }
        }
    }
}