﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Geometry;
using static Alg1.Core.Grid;

namespace Alg1.Core
{
    internal class GridGenePool
    {
        public static Point3d FindstartPointForGroupGenePool(List<Brep> group) //Finner startpunkt for hver brep-gruppe (gruppe minx, maxy)
        {
            List<(BrepFace face, BoundingBox bbox)> horisontaleFlater = new List<(BrepFace, BoundingBox)>(); //liste til horisontale flater

            // Finn alle horisontale flater i gruppen
            foreach (var brep in group)
            {
                foreach (var face in brep.Faces)
                {
                    if (!face.TryGetPlane(out Plane plane))
                        continue;

                    if (Math.Abs(plane.Normal.Z) < 0.99)
                        continue;

                    var bbox = face.GetBoundingBox(true);
                    horisontaleFlater.Add((face, bbox));
                }
            }

            if (horisontaleFlater.Count == 0)
                return Point3d.Origin;

            // Finn laveste Z-verdi
            double minZ = horisontaleFlater.Min(f => f.bbox.Min.Z);

            // Finn alle flater som ligger på denne Z-høyden (med liten toleranse)
            double tol = 0.001;
            var lavesteFlater = horisontaleFlater
                .Where(f => Math.Abs(f.bbox.Min.Z - minZ) < tol)
                .ToList();

            if (group.Count == 1 || lavesteFlater.Count == 1)
            {
                // Bare én brep i gruppa, eller bare én lavestliggende flate:
                var centroid = AreaMassProperties.Compute(lavesteFlater[0].face).Centroid;
                return centroid;
            }
            else
            {
                // Flere flater på samme laveste nivå – bruk hjørnet med minst X/Y
                Point3d hjørne = lavesteFlater
                    .Select(f => new Point3d(f.bbox.Min.X, f.bbox.Max.Y, f.bbox.Min.Z))
                    .OrderBy(p => p.X)
                    .ThenByDescending(p => p.Y)
                    .First();

                return hjørne;
            }

        }

        public static List<Point3d> GeneratePointsInDirection(Point3d start, List<double> spacings, Vector3d direction, List<Brep> breps, double tolerance = 0.1)
        {
            var points = new List<Point3d>();
            var current = start;
            points.Add(current);

            foreach (var step in spacings)
            {
                var offset = direction * step;
                var next = current + offset;

                bool isInside = IsPointInsideOrOnSurface(next, breps, tolerance);
                if (!isInside)
                    break;

                points.Add(next);
                current = next;
            }

            return points;
        }
        public static List<Surface> GenerateTrimmedSlabsPerGroupLevel(List<List<Brep>> brepGroups, double floorHeight, double tolerance = 0.1)
        {
            var slabs = new List<Surface>();

            foreach (var group in brepGroups)
            {
                BoundingBox bbox = group[0].GetBoundingBox(true);
                for (int i = 1; i < group.Count; i++)
                    bbox = BoundingBox.Union(bbox, group[i].GetBoundingBox(true));

                double minZ = bbox.Min.Z;
                double maxZ = bbox.Max.Z;
                int levels = (int)Math.Floor((maxZ - minZ) / floorHeight);

                for (int l = 1; l <= levels; l++)
                {
                    double z = minZ + l * floorHeight - (tolerance * 0.5);
                    Plane cuttingPlane = new Plane(new Point3d(0, 0, z), Vector3d.ZAxis);

                    var allCurves = new List<Curve>();

                    foreach (var brep in group)
                    {
                        Curve[] curves;
                        Point3d[] _;
                        Rhino.Geometry.Intersect.Intersection.BrepPlane(brep, cuttingPlane, tolerance, out curves, out _);
                        if (curves != null && curves.Length > 0)
                            allCurves.AddRange(curves);
                    }

                    var closed = allCurves.Where(c => c.IsClosed).ToList();
                    if (closed.Count == 0) continue;

                    var unionCurves = Curve.CreateBooleanUnion(closed, tolerance);
                    if (unionCurves == null || unionCurves.Length == 0) continue;

                    foreach (var crv in unionCurves)
                    {
                        var planarBreps = Brep.CreatePlanarBreps(new List<Curve> { crv }, tolerance);
                        if (planarBreps == null || planarBreps.Length == 0) continue;

                        foreach (var slabBrep in planarBreps)
                        {
                            var brepUnion = Brep.JoinBreps(group, tolerance);
                            if (brepUnion == null || brepUnion.Length == 0) continue;

                            var trimmed = Brep.CreateBooleanIntersection(slabBrep, brepUnion[0], tolerance);
                            if (trimmed == null || trimmed.Length == 0) continue;

                            foreach (var t in trimmed)
                            {
                                if (t.Surfaces.Count > 0)
                                    slabs.Add(t.Surfaces[0]);
                            }
                        }
                    }
                }
            }

            return slabs;
        }
    }
}
