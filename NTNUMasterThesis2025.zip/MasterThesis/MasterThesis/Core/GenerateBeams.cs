﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Alg1.Models;
using Rhino.Geometry;

namespace Alg1.Core
{
    internal class GenerateBeams
    {
        public static List<Beam> GenerateBeamsFromPoints(List<Point3d> points, double tolerance = 0.001) //For flere breper
        {
            var beams = new List<Beam>();

            // 1. Gruppér punkter etter Z-nivå (avrundet for robusthet)
            var levels = points
                .GroupBy(p => Math.Round(p.Z / tolerance) * tolerance)
                .OrderBy(zGroup => zGroup.Key)
                .ToList();

            if (levels.Count <= 1)
                return beams;  // Ingen bjelker hvis bare ett nivå

            // 2. Hopp over nederste nivå (første i sortert liste)
            foreach (var level in levels.Skip(1))
            {
                var pointsOnLevel = level.ToList();

                // 2A. Gruppér etter Y for X-bjelker
                var yGroups = pointsOnLevel.GroupBy(p => Math.Round(p.Y / tolerance) * tolerance);
                foreach (var yGroup in yGroups)
                {
                    var xSorted = yGroup.OrderBy(p => p.X).ToList();
                    for (int i = 0; i < xSorted.Count - 1; i++)
                        beams.Add(new Beam(new Line(xSorted[i], xSorted[i + 1])));
                }

                // 2B. Gruppér etter X for Y-bjelker
                var xGroups = pointsOnLevel.GroupBy(p => Math.Round(p.X / tolerance) * tolerance);
                foreach (var xGroup in xGroups)
                {
                    var ySorted = xGroup.OrderBy(p => p.Y).ToList();
                    for (int i = 0; i < ySorted.Count - 1; i++)
                        beams.Add(new Beam(new Line(ySorted[i], ySorted[i + 1])));
                }
            }

            return beams;
        }
        public static List<Beam> GenerateBeamsFromPointsSingleBrep(List<Point3d> points, double tolerance = 0.001) //For en brep
        {
            var beams = new List<Beam>();

            // 1. Gruppér punkter etter Z-nivå (avrundet for robusthet)
            var levels = points
                .GroupBy(p => Math.Round(p.Z / tolerance) * tolerance)
                .OrderBy(zGroup => zGroup.Key)
                .ToList();

            if (levels.Count <= 1)
                return beams;  // Ingen bjelker hvis bare ett nivå

            // 2. Hopp over nederste nivå (første i sortert liste)
            foreach (var level in levels.Skip(1))
            {
                var pointsOnLevel = level.ToList();

                // 2A. Gruppér etter Y for X-bjelker
                var yGroups = pointsOnLevel.GroupBy(p => Math.Round(p.Y / tolerance) * tolerance);
                foreach (var yGroup in yGroups)
                {
                    var xSorted = yGroup.OrderBy(p => p.X).ToList();
                    for (int i = 0; i < xSorted.Count - 1; i++)
                        beams.Add(new Beam(new Line(xSorted[i], xSorted[i + 1])));
                }

                // 2B. Gruppér etter X for Y-bjelker
                var xGroups = pointsOnLevel.GroupBy(p => Math.Round(p.X / tolerance) * tolerance);
                foreach (var xGroup in xGroups)
                {
                    var ySorted = xGroup.OrderBy(p => p.Y).ToList();
                    for (int i = 0; i < ySorted.Count - 1; i++)
                        beams.Add(new Beam(new Line(ySorted[i], ySorted[i + 1])));
                }
            }

            return beams;
        }
        public static List<Beam> FilterBeamsInsideOrOnBrep(List<Beam> beams, Brep brep, double tolerance = 0.01) //for en brep
        {
            return beams
                .Where(beam =>
                {
                    Point3d midpoint = beam.Axis.PointAt(0.5);
                    return brep.IsPointInside(midpoint, tolerance, true) ||
                           IsPointOnAnySurface(midpoint, brep, tolerance);
                })
                .ToList();
        }
        public static List<Beam> FilterBeamsInsideOrOnBreps(List<Beam> beams, List<Brep> breps, double tolerance = 0.01)
        {
            return beams
                .Where(beam =>
                {
                    Point3d midpoint = beam.Axis.PointAt(0.5);
                    return breps.Any(brep =>
                        brep.IsPointInside(midpoint, tolerance, true) ||
                        IsPointOnAnySurface(midpoint, brep, tolerance)
                    );
                })
                .ToList();
        }
        private static bool IsPointOnAnySurface(Point3d pt, Brep brep, double tolerance)
        {
            foreach (var face in brep.Faces)
            {
                var srf = face.UnderlyingSurface();
                if (srf.ClosestPoint(pt, out double u, out double v))
                {
                    var closest = srf.PointAt(u, v);
                    if (pt.DistanceTo(closest) < tolerance)
                        return true;
                }
            }
            return false;
        }
        public static void SplitBeamsByDirection(List<Beam> beams, out List<Beam> xBeams, out List<Beam> yBeams, double tolerance = 1e-3)
        {
            xBeams = new List<Beam>();
            yBeams = new List<Beam>();

            foreach (var beam in beams)
            {
                Vector3d dir = beam.Axis.Direction;
                dir.Unitize();

                if (Math.Abs(dir.Y) < tolerance)
                    xBeams.Add(beam);
                else if (Math.Abs(dir.X) < tolerance)
                    yBeams.Add(beam);
            }
        }
        public static void SortBeamsByLengthDominance(List<Beam> xBeams, List<Beam> yBeams, out List<Beam> primaryBeams, out List<Beam> secondaryBeams)
        {
            double avgX = xBeams.Count > 0 ? xBeams.Average(b => b.Axis.Length) : 0;
            double avgY = yBeams.Count > 0 ? yBeams.Average(b => b.Axis.Length) : 0;

            if (avgX >= avgY)
            {
                primaryBeams = new List<Beam>(xBeams);
                secondaryBeams = new List<Beam>(yBeams);
            }
            else
            {
                primaryBeams = new List<Beam>(yBeams);
                secondaryBeams = new List<Beam>(xBeams);
            }
        }
        public static void SplitPrimaryIntoMiddleAndEdgeByBoundingBox(
            List<Beam> primaryBeams,
            List<List<Brep>> grupper,
            out List<Beam> middleBeams,
            out List<Beam> edgeBeams,
            double edgeTolerance = 0.1)
        {
            middleBeams = new List<Beam>();
            edgeBeams = new List<Beam>();

            if (primaryBeams.Count == 0 || grupper.Count == 0)
                return;

            // Finn primary retning:
            Vector3d primaryDir = primaryBeams[0].Axis.Direction;
            primaryDir.Unitize();
            bool isXPrimary = Math.Abs(primaryDir.X) > Math.Abs(primaryDir.Y);

            // Her lagrer vi hvor mange ganger en bjelke har blitt klassifisert som edge
            Dictionary<Beam, int> edgeCount = primaryBeams.ToDictionary(b => b, b => 0);

            foreach (var gruppe in grupper)
            {
                foreach (var brep in gruppe)
                {
                    var bbox = brep.GetBoundingBox(true);
                    double minCoord = isXPrimary ? bbox.Min.Y : bbox.Min.X;
                    double maxCoord = isXPrimary ? bbox.Max.Y : bbox.Max.X;

                    var beamsInBrep = primaryBeams.Where(b =>
                    {
                        var midPt = b.Axis.PointAt(0.5);
                        return brep.IsPointInside(midPt, 0.01, true) ||
                               IsPointOnAnySurface(midPt, brep, 0.1);
                    }).ToList();

                    foreach (var beam in beamsInBrep)
                    {
                        double fromCoord = isXPrimary ? beam.Axis.From.Y : beam.Axis.From.X;
                        double toCoord = isXPrimary ? beam.Axis.To.Y : beam.Axis.To.X;

                        bool isEdge = Math.Abs(fromCoord - minCoord) < edgeTolerance ||
                                      Math.Abs(fromCoord - maxCoord) < edgeTolerance ||
                                      Math.Abs(toCoord - minCoord) < edgeTolerance ||
                                      Math.Abs(toCoord - maxCoord) < edgeTolerance;

                        if (isEdge)
                            edgeCount[beam] += 1;  // Øk edge-telleren for denne bjelken!
                    }
                }
            }

            //Etterpå, sorter bjelkene basert på hvor mange ganger de ble klassifisert som edge
            foreach (var kvp in edgeCount)
            {
                if (kvp.Value == 1)
                    edgeBeams.Add(kvp.Key);           // Edge i kun én brep → behold som edge
                else
                    middleBeams.Add(kvp.Key);         // Edge i flere breper → sett som middle
            }
        }
        public static void SplitPrimaryIntoMiddleAndEdgeByBoundingBoxSingleBrep(
            List<Beam> primaryBeams,
            Brep brep,
            out List<Beam> middleBeams,
            out List<Beam> edgeBeams,
            double edgeTolerance = 0.1)
        {
            middleBeams = new List<Beam>();
            edgeBeams = new List<Beam>();

            if (primaryBeams.Count == 0)
                return;

            // Finn primary retning:
            Vector3d primaryDir = primaryBeams[0].Axis.Direction;
            primaryDir.Unitize();
            bool isXPrimary = Math.Abs(primaryDir.X) > Math.Abs(primaryDir.Y);

            // Finn min og max basert på BEAM-coordinater:
            double minCoord = primaryBeams.Min(b => isXPrimary ? b.Axis.From.Y : b.Axis.From.X);
            double maxCoord = primaryBeams.Max(b => isXPrimary ? b.Axis.From.Y : b.Axis.From.X);

            foreach (var beam in primaryBeams)
            {
                double fromCoord = isXPrimary ? beam.Axis.From.Y : beam.Axis.From.X;
                double toCoord = isXPrimary ? beam.Axis.To.Y : beam.Axis.To.X;
                double midCoord = isXPrimary ? beam.Axis.PointAt(0.5).Y : beam.Axis.PointAt(0.5).X;

                // Sjekk hvor nær bjelken er til min eller max av ALLE bjelker:
                bool nearMin = Math.Abs(fromCoord - minCoord) < edgeTolerance ||
                               Math.Abs(toCoord - minCoord) < edgeTolerance ||
                               Math.Abs(midCoord - minCoord) < edgeTolerance;

                bool nearMax = Math.Abs(fromCoord - maxCoord) < edgeTolerance ||
                               Math.Abs(toCoord - maxCoord) < edgeTolerance ||
                               Math.Abs(midCoord - maxCoord) < edgeTolerance;

                if (nearMin || nearMax)
                    edgeBeams.Add(beam);
                else
                    middleBeams.Add(beam);
            }

        }
        public static void SplitPrimaryByMidpointExtremes(
    List<Beam> primaryBeams,
    out List<Beam> middleBeams,
    out List<Beam> edgeBeams,
    double tolerance = 1e-3)
        {
            middleBeams = new List<Beam>();
            edgeBeams = new List<Beam>();

            if (primaryBeams == null || primaryBeams.Count == 0)
                return;

            // 1) Finn primærretning (X vs Y)
            var dir = primaryBeams[0].Axis.Direction;
            dir.Unitize();
            bool isXPrimary = Math.Abs(dir.X) < Math.Abs(dir.Y);

            // 2) Hent midtkoordinat for hver bjelke
            var midCoords = primaryBeams
                .Select(b => {
                    var m = b.Axis.PointAt(0.5);
                    return isXPrimary ? m.X : m.Y;
                })
                .ToList();

            // 3) Finn ytterpunktene
            double minMid = midCoords.Min();
            double maxMid = midCoords.Max();

            // 4) Klassifiser
            for (int i = 0; i < primaryBeams.Count; i++)
            {
                var beam = primaryBeams[i];
                double mc = midCoords[i];
                bool isEdge = Math.Abs(mc - minMid) < tolerance
                           || Math.Abs(mc - maxMid) < tolerance;

                if (isEdge)
                    edgeBeams.Add(beam);
                else
                    middleBeams.Add(beam);
            }
        }

    }
}

