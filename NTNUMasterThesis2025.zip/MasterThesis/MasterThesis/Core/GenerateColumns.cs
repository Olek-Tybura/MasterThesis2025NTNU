﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Alg1.Models;
using Rhino.Geometry;

namespace Alg1.Core
{
    internal class GenerateColumns
    {
        public static List<Column> GenerateColumnsFromPoints(List<Point3d> points, double tolerance = 0.001)
        {
            var columns = new List<Column>(); //Liste til søylene

            // Gruppér punktene etter X/Y (med avrunding for robust matching)
            var groups = points.GroupBy(pt => new {
                X = Math.Round(pt.X / tolerance) * tolerance,
                Y = Math.Round(pt.Y / tolerance) * tolerance
            });

            foreach (var group in groups)
            {
                var sorted = group.OrderBy(p => p.Z).ToList();
                for (int i = 0; i < sorted.Count - 1; i++)
                {
                    // Lag en søyle mellom to påfølgende Z-nivåer
                    var line = new Line(sorted[i], sorted[i + 1]);
                    columns.Add(new Column(line)); // Legg til søyle i listen
                }
            }

            return columns;
        }
    }
}
