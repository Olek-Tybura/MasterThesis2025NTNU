﻿using System;
using System.Collections.Generic;
using System.Linq;
using Grasshopper.Kernel;
using Rhino.Geometry;
using Alg1.Models;
using static Alg1.Core.Grid;
using static Alg1.Core.Breps;
using static Alg1.Core.GenerateColumns;
using static Alg1.Core.GenerateBeams;
using static Alg1.Core.GenerateSlabs;

namespace Alg1
{
    public class CreateAdvacedBuilding : GH_Component
    {
        
        public CreateAdvacedBuilding()
          : base("CreateAdvacedBuilding", "Nickname",
              "Creates a building in a brep or a brep grpup. Startingpoint in mid if one brep, startingpoint in corner if more. The structure extends to fill the whole brep",
              "Category", "Building")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddBrepParameter("Breps", "B", "Building volumes", GH_ParamAccess.list);
            pManager.AddPointParameter("Starting Point", "SP", "", GH_ParamAccess.item, new Point3d(0, 0, 0));
            pManager.AddNumberParameter("X spacing", "XS", "Spacing between columns in X direction", GH_ParamAccess.item);
            pManager.AddNumberParameter("Y spacing", "YS", "Spacing between columns in Y direction", GH_ParamAccess.item);
            pManager.AddNumberParameter("Floor height", "FH", "Height of each floor", GH_ParamAccess.item);
            pManager.AddBooleanParameter("FilterCornerPoints", "", "", GH_ParamAccess.item, true);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "", "", GH_ParamAccess.item);
        }

        
        protected override void SolveInstance(IGH_DataAccess DA)
        {
            List<Brep> breps = new List<Brep>();
            Point3d basePoint = Point3d.Origin;
            double xSpac = 0, ySpac = 0, fh = 0;

            DA.GetDataList(0, breps);
            DA.GetData(1, ref basePoint);
            DA.GetData(2, ref xSpac);
            DA.GetData(3, ref ySpac);
            DA.GetData(4, ref fh);

            var grupper = GroupIntersectingBreps(breps);
            var allGridPoints = new List<Point3d>();
            var allintersectionPoints = new List<Point3d>();
            var allCornerPoints = new List<Point3d>();

            Building building = new Building();


            foreach (var gruppe in grupper)
            {
                Point3d localStart = FindstartPointForGroup(gruppe); //Finner lokalt startpunkt for hver gruppe
                Point3d justert = localStart + new Vector3d(basePoint.X, basePoint.Y, 0); //Lager sammenheng mellom startingpoint og lokal startpunkt

                var grid = Generate3DGrid(gruppe, justert, xSpac, ySpac, fh);
                allGridPoints.AddRange(grid.ConvertAll(gp => gp.Point));


                var gridLines = CreateLinesThroughGridPoints(grid, 10); // ekstra lengde 10 i begge retninger
                var intersectionPoints = FindIntersectionsWithBrep(gridLines, gruppe, 0.001); // Finn kryssingspunktene
                allintersectionPoints.AddRange(intersectionPoints); // Legg til kryssingspunktene i gridet

                var cornerPts = GenerateCornerPointsPerBrep(gruppe, fh);
                allCornerPoints.AddRange(cornerPts);

            }

            double distanceThreshold = 1.2;
            bool keepAll = true;
            DA.GetData(5, ref keepAll);

            var gridPointsForBeams = new List<Point3d>(allGridPoints);
            var cornerPointsForBeams = new List<Point3d>(allCornerPoints);
            var intersectionPointsForBeams = new List<Point3d>(allintersectionPoints);

            // Fjern intersectionpunkter som overlapper med corner
            allintersectionPoints = allintersectionPoints
                .Where(ip => !allCornerPoints.Any(cp => cp.DistanceTo(ip) < 0.001))
                .ToList();

            // Fjern intersectionPoints som overlapper med hovedgrid før videre filtrering
            allintersectionPoints = allintersectionPoints
                .Where(ip => !allGridPoints.Any(gp => gp.DistanceTo(ip) < 0.001)) // eller annen lav toleranse
                .ToList();

            // Fjern hjørnepunkter som overlapper med hovedgrid
            allCornerPoints = allCornerPoints
                .Where(cp => !allGridPoints.Any(gp => gp.DistanceTo(cp) < 0.001))
                .ToList();

            // Kopier originalen før filtrering
            var originalIntersections = new List<Point3d>(allintersectionPoints);



            if (!keepAll)
            {
                // Trinn 1: Finn intersection-punkter nær hovedgrid
                var intersectCloseToGrid = allintersectionPoints
                    .Where(ip => allGridPoints.Any(gp => gp.DistanceTo(ip) <= distanceThreshold))
                    .ToList();

                // Trinn 2: Fjern disse fra intersection-punktene
                allintersectionPoints = allintersectionPoints
                    .Except(intersectCloseToGrid)
                    .ToList();

                // Trinn 3: Bruk ORIGINALE intersection-punkter til å filtrere corner-punktene
                allCornerPoints = allCornerPoints
                    .Where(cp => !originalIntersections.Any(ip => cp.DistanceTo(ip) <= distanceThreshold))
                    .ToList();

                // Trinn 4: Fjern corner-punkter som er nær hovedgrid-punktene
                allCornerPoints = allCornerPoints
                    .Where(cp => !allGridPoints.Any(gp => cp.DistanceTo(gp) <= distanceThreshold))
                    .ToList();
            }
            else
            {
                // True: Fjern grid-punkter nær intersection-punkter
                allGridPoints = allGridPoints
                    .Where(gp => !allintersectionPoints.Any(ip => gp.DistanceTo(ip) <= distanceThreshold))
                    .ToList();

                // Fjern grid-punkter som ligger ≤ 1 m fra corner-punktene
                allGridPoints = allGridPoints
                    .Where(gp => !allCornerPoints.Any(cp => gp.DistanceTo(cp) <= distanceThreshold))
                    .ToList();

                // Fjern intersection-punkter som ligger ≤ 1 m fra corner-punktene
                allintersectionPoints = allintersectionPoints
                    .Where(ip => !allCornerPoints.Any(cp => cp.DistanceTo(ip) <= distanceThreshold))
                    .ToList();


            }

            var samletPunkter = new List<Point3d>();
            samletPunkter.AddRange(allGridPoints.Concat(allintersectionPoints).Concat(allCornerPoints)); //Legger til alle punktene i en liste
            samletPunkter = Point3d.CullDuplicates(samletPunkter, 0.001).ToList();                      //Fjerner duplikater

            //Bjelker
            var gridForBeams = gridPointsForBeams
            .Where(gp =>
                !intersectionPointsForBeams.Any(ip => gp.DistanceTo(ip) <= distanceThreshold) &&
                !cornerPointsForBeams.Any(cp => gp.DistanceTo(cp) <= distanceThreshold))
            .ToList();

            var intersectionForBeams = intersectionPointsForBeams
                .Where(ip => !cornerPointsForBeams.Any(cp => cp.DistanceTo(ip) <= distanceThreshold))
                .ToList();

            var samletPunkterForBeams = new List<Point3d>();
            samletPunkterForBeams.AddRange(gridForBeams.Concat(intersectionForBeams).Concat(cornerPointsForBeams));

            double snapTol = 1e-3; // 1 mm
            Point3d Snap(Point3d p)
            {
                return new Point3d(
                  Math.Round(p.X / snapTol) * snapTol,
                  Math.Round(p.Y / snapTol) * snapTol,
                  Math.Round(p.Z / snapTol) * snapTol
                );
            }

            samletPunkterForBeams = samletPunkterForBeams
  .Select(p => Snap(p))
  .ToList();
            samletPunkterForBeams = Point3d.CullDuplicates(samletPunkterForBeams, 0.001).ToList();

            var beams = GenerateBeamsFromPoints(samletPunkterForBeams);
            beams = FilterBeamsInsideOrOnBreps(beams, breps);

            building.Beams = beams; //Alle bjelker

            List<Beam> xBeams, yBeams;
            SplitBeamsByDirection(beams, out xBeams, out yBeams); //Splitter bjelker i x og y-retning
            SortBeamsByLengthDominance(xBeams, yBeams, out var primaryBeams, out var secondaryBeams); //Sorterer primary and secondary
            SplitPrimaryIntoMiddleAndEdgeByBoundingBox(primaryBeams, grupper, out var middleBeams, out var edgeBeams); //Finner edge og interalbeams. 

            //Setter opp BeamSublists:
            building.BeamSublists = new List<List<Beam>>
            {
                middleBeams, // Index 0 = Internal beams
                edgeBeams,   // Index 1 = Edge beams
                secondaryBeams // Index 2 = Secondary beams
            };


            //Søyler
            var columns = GenerateColumnsFromPoints(samletPunkter);
            building.Columns = columns;

            //Dekke
            var alleBreps = grupper.SelectMany(g => g).ToList();
            var slabs = SplitSlabsWithBeams(GenerateSlab(samletPunkterForBeams, alleBreps), beams);
            building.Slabs = slabs;





            DA.SetData(0, building);
        }
        

        /// <summary>
        /// Checks whether two lines are colinear (same direction) within a given tolerance.
        /// </summary>
        private bool AreColinear(Line a, Line b, double tolerance)
        {
            var dirA = a.Direction;
            var dirB = b.Direction;
            dirA.Unitize();
            dirB.Unitize();
            return Math.Abs(dirA * dirB - 1.0) < tolerance || Math.Abs(dirA * dirB + 1.0) < tolerance;
        }

        /// <summary>
        /// Provides an Icon for the component.
        /// </summary>
        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("B2C4CD3D-F0FE-4B77-BEB4-D12A8B40F8FC"); }
        }
    }
}