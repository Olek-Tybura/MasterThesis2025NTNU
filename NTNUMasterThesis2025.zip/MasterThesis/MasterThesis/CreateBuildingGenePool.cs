﻿using System;
using System.Collections.Generic;
using System.Linq; 
using Grasshopper.Kernel;
using Grasshopper.Kernel.Data;
using Grasshopper.Kernel.Types;
using Rhino.Geometry;
using Alg1.Models;
using static Alg1.Core.Grid;
using static Alg1.Core.Breps;
using static Alg1.Core.GenerateColumns;
using static Alg1.Core.GenerateBeams;
using static Alg1.Core.GridGenePool;
using static Alg1.Core.GenerateSlabs;
using Alg1.Core;

namespace Alg1
{
    public class CreateBuildingGenePool : GH_Component
    {
        
        public CreateBuildingGenePool()
          : base("CreateBuildingGenePool", "Nickname",
              "Creates grid with GenePool",
              "Category", "Building")
        {
        }

        protected override void RegisterInputParams(GH_Component.GH_InputParamManager pManager)
        {
            pManager.AddBrepParameter("Brep", "B", "", GH_ParamAccess.list);
            pManager.AddNumberParameter("X-spacing", "", "", GH_ParamAccess.tree);
            pManager.AddNumberParameter("Y-Spacing", "", "", GH_ParamAccess.tree);
            pManager.AddNumberParameter("Z-Spacing", "", "", GH_ParamAccess.item);
        }

        protected override void RegisterOutputParams(GH_Component.GH_OutputParamManager pManager)
        {
            pManager.AddGenericParameter("Building", "", "", GH_ParamAccess.item);
        }

        protected override void SolveInstance(IGH_DataAccess DA)
        {
            List<Brep> breps = new List<Brep>(); //Liste for breper
            GH_Structure<GH_Number> xSpacing = new GH_Structure<GH_Number>(); //liste over x-spacing for hver brep gruppe
            GH_Structure<GH_Number> ySpacing = new GH_Structure<GH_Number>(); //liste over y-spacing for hver brep gruppe
            double zSpacing = 0;

            if (!DA.GetDataList(0, breps)) return;
            if (!DA.GetDataTree(1, out xSpacing)) return; //out - sender variabel inn i en metode
            if (!DA.GetDataTree(2, out ySpacing)) return;
            if (!DA.GetData(3, ref zSpacing)) return;
            Building building = new Building();

            // Hent spacing-liste fra {0}
            List<double> xSpacingList = new List<double>(); //Liste for å lagre xspacing
            if (xSpacing.Branches.Count > 0) //sjekker at strukturen har minst en gren
            {
                foreach (var val in xSpacing.Branches[0]) //Henter alle tallene i gren [0]. Kan endres ved behov for flere grener. 
                    xSpacingList.Add(val.Value); //Henter ut verdiene og legger til i spacing-listen
            }

            // Akkurat samme som over
            List<double> ySpacingList = new List<double>();
            if (ySpacing.Branches.Count > 0)
            {
                foreach (var val in ySpacing.Branches[0])
                    ySpacingList.Add(val.Value);
            }

            List<double> zSpacingList = new List<double>();
            if (zSpacing > 0)
                for (double z = zSpacing; z < 1000; z += zSpacing) // maksverdi settes høyt – avgrenses av volumet
                    zSpacingList.Add(zSpacing);

            var grupper = GroupIntersectingBreps(breps);

            Point3d startPts = FindstartPointForGroupGenePool(breps); // Finn startpunkt for hele brep-lista

            List<Point3d> PtsX = GeneratePointsInDirection(startPts, xSpacingList, new Vector3d(1, 0, 0), breps); // Genererer punkter i X-retning:

            List<Point3d> totalPts = new List<Point3d>(); //// Genererer grid i Y- og Z-retning

            // Så for Y-retning
            foreach (var ptX in PtsX)
            {
                var PtsY = GeneratePointsInDirection(ptX, ySpacingList, new Vector3d(0, -1, 0), breps);

                foreach (var ptY in PtsY)
                {
                    var PtsZ = GeneratePointsInDirection(ptY, zSpacingList, new Vector3d(0, 0, 1), breps);
                    totalPts.AddRange(PtsZ);
                }
            }
            var columns = GenerateColumnsFromPoints(totalPts);

            var beams = FilterBeamsInsideOrOnBreps(GenerateBeamsFromPoints(totalPts), breps);
            building.Beams = beams; //Alle bjelker

            List<Beam> xBeams, yBeams;
            SplitBeamsByDirection(beams, out xBeams, out yBeams); //Splitter bjelker i x og y-retning
            SortBeamsByLengthDominance(xBeams, yBeams, out var primaryBeams, out var secondaryBeams); //Sorterer primary and secondary
            SplitPrimaryIntoMiddleAndEdgeByBoundingBox(primaryBeams, grupper, out var middleBeams, out var edgeBeams); //Finner edge og interalbeams. 

            //Setter opp BeamSublists:
            building.BeamSublists = new List<List<Beam>>
            {
                middleBeams, // Index 0 = Internal beams
                edgeBeams,   // Index 1 = Edge beams
                secondaryBeams // Index 2 = Secondary beams
            };


            // var slabs = SplitSlabsWithBeams(GenerateSlab(totalPts, breps), beams);
            var slabs = GenerateSlabsFromPoints(
    totalPts,
    defaultThickness: 0.2,
    tolerance: 1e-6);

            building.Columns = columns;
            building.Slabs = slabs;

            DA.SetData(0, building);
        }

        protected override System.Drawing.Bitmap Icon
        {
            get
            {
                //You can add image files to your project resources and access them like this:
                // return Resources.IconForThisComponent;
                return null;
            }
        }

        /// <summary>
        /// Gets the unique ID for this component. Do not change this ID after release.
        /// </summary>
        public override Guid ComponentGuid
        {
            get { return new Guid("F81C9B5F-36B6-479F-BDF1-91DEC3A7FD28"); }
        }
    }
}