﻿using System;
using Rhino.Geometry;

namespace Alg1.Models
{
    public class Bracing
    {
        public Line Axis { get; set; }  // Bracing's central axis

        public Bracing(Line axis)
        {
            Axis = axis;
        }
    }
}