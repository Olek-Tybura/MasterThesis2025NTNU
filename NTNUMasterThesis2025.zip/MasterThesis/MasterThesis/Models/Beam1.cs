﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Rhino.Geometry;

namespace Alg1.Models
{
    internal class Beam1
    {
        internal class Beam2
        {
            public Curve Axis { get; set; }  // Beam's central axis

            public Beam2(Curve axis)
            {
                Axis = axis;
            }
        }
    }
}
