﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Grasshopper;


namespace Alg1.Models
{
    internal class Building
    {
        // Properties
        public string Name { get; set; }
        public int Id { get; set; }
        public List<Column> Columns { get; set; }
        public List<Beam> Beams { get; set; }
        public List<Slab> Slabs { get; set; }
        public List<Bracing> Bracings { get; set; } 


        public List<List<Beam>> BeamSublists { get; set; }

        // Default Constructor
        public Building()
        {
            Columns = new List<Column>();
            Beams = new List<Beam>();
            Slabs = new List<Slab>();
            BeamSublists = new List<List<Beam>>();
            Bracings = new List<Bracing>();
        }

        // Parameterized Constructor (Optional)
        public Building(string name, int id)
        {
            Name = name;
            Id = id;
            Columns = new List<Column>();
            Beams = new List<Beam>();
            Slabs = new List<Slab>();
        }
    }
}
